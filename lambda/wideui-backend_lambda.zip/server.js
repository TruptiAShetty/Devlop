/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const express = require("express");
require("./src/database/db");
const serverless = require("serverless-http");
const app = express();
const cors = require("cors");
const morgan = require("morgan");

const APP_CONSTANTS = require("./src/core/constants/app.constant");
// app routes
const authenticationRoute = require("./src/routes/authentication.route");
const ownerRoute = require("./src/routes/owner.route");
const vesselRoute = require("./src/routes/vessel.route");
const signalRoute = require("./src/routes/signal.route");
const datapointsRoute = require("./src/routes/datapoint.route");
const staticdataRoute = require("./src/routes/staticdata.route");
const alarmeventRoute = require("./src/routes/alarmevent.route");
const downloadDataRoute = require("./src/routes/download.route");
const favouriteRoute = require("./src/routes/favourite.route");
const renameRoute = require("./src/routes/rename.route");
const shareDataRoute = require("./src/routes/share.route");
const userRoute = require("./src/routes/user.route");
const kpiOverview = require("./src/routes/kpioverview.route");
const faultList = require("./src/routes/faultlist.route");
const fleetOverview = require("./src/routes/fleetoverview.route");
const lastUpdated = require("./src/routes/lastupdated.route");
let PORT;

// console.log("process", `${process.env.NODE_ENV}`)

if (process.env.NODE_ENV !== "lambda") {
	PORT = process.env.PORT || 7000;
	require("dotenv").config({ path: "./enviornment/.env.local" });

	// local logging middleware
	if (process.env.NODE_ENV === "local") {
		app.use(morgan("dev"));
	}
}

const errorHandler = require("./src/middlewares/error-handler.middleware");
const AuthMiddleWare = require("./src/middlewares/auth.middleware");
const auth = new AuthMiddleWare();

app.use(cors());
app.use((req, res, next) => {
	res.setHeader('Connection', 'keep-alive');
	res.setHeader('Keep-Alive', 'timeout=30');
	res.setHeader("Access-Control-Allow-Headers", "X-Requested-With,content-type");
	res.setHeader("Access-Control-Allow-Origin", "*");
	res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
	res.setHeader("Access-Control-Allow-Credentials", true);
	next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
	res.status(200).send("Hello World !");
});

app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/login`, authenticationRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/owners`, ownerRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/vessels`, vesselRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/signals`, signalRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/datapoints`, datapointsRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/staticdata`, staticdataRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/alarmevents`, alarmeventRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/download`, downloadDataRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/favourite`, favouriteRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/rename`, renameRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/share`, shareDataRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/user`, userRoute);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/kpioverview`, kpiOverview);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/faultlist`, faultList);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/fleetoverview`, fleetOverview);
app.use(`${APP_CONSTANTS.API_ENDPOINT_PREFIX}/lastupdated`, lastUpdated);

// always keep it after all routers
app.use(errorHandler);

if (process.env.NODE_ENV !== "lambda") {
	const server = app.listen(PORT, () => {
		console.log(`node-express server running in ${process.env.NODE_ENV} mode on ${PORT}`);
	});

	server.timeout = 0;

	process.on("error", (err) => {
		// Handle error
		console.log("error: " + err);
	});

	process.on("uncaughtException", (err) => {
		console.log("Caught exception: " + err);
	});

	// Handle unhandled promise rejections
	process.on("unhandledRejection", (err) => {
		console.log(`Error from global handler: ${err.message}`);
	});
} else {
	module.exports.handler = serverless(app);
}
