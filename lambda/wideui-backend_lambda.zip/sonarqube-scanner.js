/*
 *   Copyright (c) 2022 Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com). All rights reserved.
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const scanner = require("sonarqube-scanner");
console.log("arguments: " + process.argv.slice(2));

if (process.argv.slice(2) == 1) {
  require("dotenv").config({ path: "./enviornment/.env.dev" });
  console.log("@@@@@@", process.env.SONARQUBE_SERVER_URL, process.env.SONARQUBE_TOKEN);
} else if (process.argv.slice(2) == 2) {
  require("dotenv").config({ path: "./enviornment/.env.qa" });
  console.log("###", process.env.SONARQUBE_SERVER_URL, process.env.SONARQUBE_TOKEN);
} else {
  require("dotenv").config({ path: "./enviornment/.env.prod" });
  console.log("###", process.env.SONARQUBE_SERVER_URL, process.env.SONARQUBE_TOKEN);
}

const lintExclusions = `**/bootstrap.js, 
                        **/bootstrap.tsx, 
                        **/App.js, 
                        **/App.tsx, 
                        **/navbar.component.tsx,
                        **/__tests__/**, 
                        **/*.test.tsx, 
                        **/dist/**/*, 
                        **/dist-docker-images/**/*,  
                        **/public/**/*, 
                        **/script/**/*, 
                        **/Dockerfile.dev, 
                        **/Dockerfile.prod, 
                        **/nginx.conf, 
                        **/package-json, 
                        **/package-lock.json, 
                        **/sonarqube.scanner.js, 
                        **/webpack.config.js, 
                        **/webpack.docker.js, 
                        **/webpack.prod.js,
                        **/*.test.js`;

const testExclusions = `src/**/*.d.ts,
                        src/setupTests.ts,
                        src/reportWebVitals.ts,
                        src/bootstrap.js,
                        src/bootstrap.ts,
                        src/index.ts,
                        src/index.js,
                        src/core/constants/**/*,
                        src/core/interfaces/**/*,
                        src/core/store/**/*,
                        src/components/authapp.js,
                        src/components/dashboardapp.js,
                        src/components/headerapp.js`;

scanner(
  {
    serverUrl: `${process.env.SONARQUBE_SERVER_URL}`,
    token: `${process.env.SONARQUBE_TOKEN}`,
    options: {
      "sonar.projectKey": "server",
      "sonar.sources": "./src",
      "sonar.exclusions": `${lintExclusions}`,
      "sonar.tests": "./src",
      "sonar.test.inclusions": "./src/**/*.test.js ",
      "sonar.coverage.exclusions": `${testExclusions}`,
      "sonar.typescript.lcov.reportPaths": "coverage/lcov.info",
      "sonar.testExecutionReportPaths": "test-report.xml"
      // "sonar.eslint.reportPaths": "eslint-report.json"
    }
  },
  () => process.exit()
);
