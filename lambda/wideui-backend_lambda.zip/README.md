- ## Wideui-backend

1. Clone the repository and cd into /wideui-backend
2. run npm install
3. For time being, just add MYSQL password to db.js file, in password field
4. run `npm start` to run the node express server with restful apis.
5. Open up browswer and run `localhost:7000`. Check broswer if `Hellow world !` is visible. If so, backend is up & running successfully.

6. Just open postman-collection file in POSTMAN and load postman enviornment. Then start using APIs
