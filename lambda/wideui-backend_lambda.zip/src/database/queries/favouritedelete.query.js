/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");

class FavoriteDeleteQuery {
	constructor() {}

	// @desc      deleting favoute
	static favDelete = async (payload, cb) => {
		console.log("payload", payload);
		let favorite_name = payload.favorite_name;
		const user_id = payload.user_id;
		let query = `DELETE FROM wide_ui_config.favourites WHERE favorite_name='${favorite_name}' and user_id = '${user_id}';`;
		console.log("query:",query);
		let queries = [];
		queries.push(query);
		try {
			const queryResults = await Promise.all(
				queries.map(async (query) => {
					return new Promise((resolve, reject) =>
						mysql.query(query, [payload], (err, result) => {
							if (err) {
								return reject(err);
							} else {
								return resolve({ message: "Favorite delete successfully" });
							}
						})
					);
				})
			);
			return cb(null, queryResults);
		} catch (e) {
			return cb(e);
		}
	};
}

module.exports = FavoriteDeleteQuery;
