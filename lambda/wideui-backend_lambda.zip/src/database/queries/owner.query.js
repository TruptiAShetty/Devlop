/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const CommonQuery = require("./common.query");

class OwnerQuery {
	constructor() {}

	static postOwners(id, cb) {
		if (id.length === 1 && id.includes(-1)) {
			const query = ` SELECT 
                                t1.id, 
                                t1.owner_name, 
                                t1.country, 
                                t1.email,
                                t2.imo  
                            FROM 
                                wingd.evt_owners as t1
                            INNER JOIN
                                wingd.evt_ships as t2 
                            ON 
                                t1.id = t2.owner_id 
                            ORDER BY 
                                t1.owner_name`;

			console.log("query to fetch all fleets", query);

			CommonQuery.excecuteQuery(query, [], cb);
		} else {
			const query = ` SELECT 
                                t1.id, 
                                t1.owner_name, 
                                t1.country, 
                                t1.email,
                                t2.imo  
                            FROM
                                wingd.evt_owners  as t1
                            INNER JOIN
                                 wingd.evt_ships  as t2
                            ON 
                                t1.id = t2.owner_id 
                            WHERE 
                                t1.id IN (?) 
                            ORDER BY 
                                t1.owner_name`;

			// console.log("query", query);
			CommonQuery.excecuteQuery(query, id, cb);
		}
	}
}

module.exports = OwnerQuery;
