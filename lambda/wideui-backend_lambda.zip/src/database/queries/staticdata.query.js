/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");
const CommonQuery = require("./common.query");

class StaticdataQuery {
	constructor() {}

	static postStaticdata(imo, owner_id, enginenumber, eng_number, dataset, param, cb) {
		let query = ` SELECT json_arrayagg(obj) as ${mysql.escape(dataset)} FROM ( `;
		for (let i = 0; i < param.length; i++) {
			if (i !== 0) {
				query = query + " UNION ALL ";
			}

			query =
        query +
        ` SELECT 
                        json_object(
                                    ${mysql.escape(param[i])}, 
                                    json_arrayagg(json_array(x.tier, x.load, x.value)
                                    )) AS obj 
                  FROM
                        wingd_${owner_id}_eds.${dataset}s_${imo} as x
                  WHERE 
                        name=${mysql.escape(param[i])} and eng_number=${eng_number}
                `;
		}

		query = query + ") x";

		CommonQuery.excecuteQuery(query, [], cb);
	}
}

module.exports = StaticdataQuery;
