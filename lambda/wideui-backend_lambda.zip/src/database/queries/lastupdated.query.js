/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");

class LastUpdatedQuery {
    static getSignaldate = async (vessels, cb) => {
        console.log("LastUpdatedQuery Payload:", vessels)
        const queries = [];

        for (let i = 0; i < vessels.length; i++) {
            let mysqlQuery = '';
            if (vessels[i].signals) {
                for (let j = 0; j < vessels[i].signals.length; j++) {
                    mysqlQuery = " SELECT json_arrayagg(obj) as RESULT FROM (";
                    let query = '';
                    for (let k = 0; k < vessels[i].signals[j].col_name.length; k++) {
                        if (k !== 0) {
                            mysqlQuery = mysqlQuery + " UNION ALL";
                        }
                        if (vessels[i].signals[j].col_name.length > 1) {
                            query = "(";
                        }
                        const signal_col_name = vessels[i].signals[j].col_name[k];
                        const groupName = vessels[i].signals[j].groupName;

                        let datapointQuery = `json_object(
                        "signaldate",UNIX_TIMESTAMP(signaldate)*1000,
                        "imo",${vessels[i].imo},
                        '${signal_col_name}',${signal_col_name}
                        ) AS obj`

                        query = query + ` SELECT ${datapointQuery}
                            FROM 
                                wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName} 
                                order by signaldate DESC limit 1
                                
                            `;
                        if (vessels[i].signals[j].col_name.length > 1) {
                            query = query + ")";
                        }
                        mysqlQuery = mysqlQuery + query;
                    }
                    mysqlQuery = mysqlQuery + ") x ";
                    queries.push(mysqlQuery);
                }
            } else {
                let sqlQuery = '';

                mysqlQuery = " SELECT json_arrayagg(obj) as RESULT FROM (";

                let datapointQuery = `json_object(
                        "signaldate",UNIX_TIMESTAMP(signaldate)*1000,
                        "imo",${vessels[i].imo}
                        ) AS obj`
                sqlQuery = ` SELECT ${datapointQuery}
                            FROM 
                                wingd_${vessels[i].owner_id}.evt_config
                                order by signaldate DESC limit 1
                                
                            `;
                mysqlQuery = mysqlQuery + sqlQuery;
                mysqlQuery = mysqlQuery + ") x ";
                queries.push(mysqlQuery);
            }
        }

        try {
            const queryResults = await Promise.all(
                queries.map(async (query) => {
                    return new Promise((resolve, reject) =>
                        mysql.query(query, [], (err, result) => {
                            if (err || result[0].RESULT === null) {
                                return reject(err);
                            } else {
                                const separeteQueryResult = [];
                                result = JSON.parse(result[0].RESULT);
                                for (const r of result) {
                                    if (typeof r === "string") {
                                        separeteQueryResult.push(JSON.parse(r));
                                    } else {
                                        separeteQueryResult.push(r);
                                    }
                                }
                                return resolve(separeteQueryResult);
                            }
                        })
                    );
                })
            );
            return cb(null, queryResults);
        } catch (e) {
            return cb(e);
        }
    }
}

module.exports = LastUpdatedQuery;