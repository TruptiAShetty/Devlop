/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");

class GetIndexesQuery {
	constructor() { }

	// @desc      get start/end indexes by using start date and end date
	static getIndexes = async (payload, cb) => {

		const {starttime,endtime,vessels} = payload;
		const queries = [];
		let query;
		for (let i = 0; i < vessels.length; i++) {
			for (let j = 0; j < vessels[i].signals.length; j++) {
				for (let k = 0; k < vessels[i].signals[j].col_name.length; k++) {
					const groupName = vessels[i].signals[j].groupName;
					query = `
							(SELECT signaldate,id
								FROM wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName}
								where signaldate between '${starttime}' and '${endtime}' limit 1)
							UNION ALL
							(SELECT signaldate,id
								FROM wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName}
								where signaldate between '${starttime}' and '${endtime}' ORDER BY signaldate DESC limit 1)
								;
							`
							queries.push(query);
				}
			}
		}

		try {
			const queryResults = await Promise.all(
				queries.map(async (query) => {
					return new Promise((resolve, reject) =>
						mysql.query(query, [], (err, result) => {
							if (err) {
								return reject(err);
							} else {
								const separeteQueryResult = [];

								for (const r of result) {
									if (typeof r === "string") {
										separeteQueryResult.push(JSON.parse(r));
									} else {
										separeteQueryResult.push(r);
									}
								}
								return resolve(separeteQueryResult);
							}
						})
					);
				})
			);
			return cb(null, queryResults);
		} catch (e) {
			return cb(e);
		}
	};
}

module.exports = GetIndexesQuery;
