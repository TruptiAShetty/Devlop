/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const xlsx = require("xlsx");
const fetchFile = require("../../services/s3-bucket.service");

class AlarmeventQuery {
	constructor() {}

	static async getAlarmevents(payload, cb) {
		const startDatetime = new Date(payload.starttime);

		const startFullYearUTC = startDatetime.getUTCFullYear().toString();
		const startMonthUTC = (startDatetime.getUTCMonth() + 1).toString().padStart(2, "0");
		const startDateUTC = startDatetime.getUTCDate().toString().padStart(2, "0");
		const startHourUTC = startDatetime.getUTCHours().toString().padStart(2, "0");
		const startSecondUTC = startDatetime.getUTCMinutes().toString().padStart(2, "0");

		const starttimeStamp = startDatetime.getTime();

		const folderPrefix = `${
			startFullYearUTC + startMonthUTC + startDateUTC + startHourUTC + startSecondUTC
		}`;

		const endDatetime = new Date(payload.endtime);

		const endFullYearUTC = endDatetime.getUTCFullYear().toString();
		const endMonthUTC = (endDatetime.getUTCMonth() + 1).toString().padStart(2, "0");

		const endtimeStamp = endDatetime.getTime();

		console.log("folderprefix", folderPrefix);

		const filePath = `${payload.imo}/wice_log/`;

		if (filePath.includes("undefined")) {
			return cb("file from S3 bucket not found !");
		}

		try {
			const folderContent = await fetchFile.listBucketContent(filePath);

			const filesToBeDownloaded = [];
			if (folderContent?.Contents) {
				for (const record of folderContent.Contents) {
					if (record.Key.includes(".csv")) {
						const splitKey = record.Key.split("/");
						if (splitKey.length) {
							const splitYear = splitKey[2].split("=");
							if (splitYear.length) {
								if (
									parseInt(startFullYearUTC) >=
                  parseInt(splitYear[1]) <=
                  parseInt(endFullYearUTC)
								) {
									const splitMonth = splitKey[3].split("=");
									if (splitMonth.length) {
										if (
											parseInt(startMonthUTC) >=
                      parseInt(splitMonth[1]) <=
                      parseInt(endMonthUTC)
										) {
											filesToBeDownloaded.push(fetchFile.getBufferFromS3Promise(record.Key, cb));
										}
									}
								}
							}
						}
					}
				}

				const results = await Promise.all(filesToBeDownloaded);

				let parsedData = [];

				if (!results?.length) {
					cb(null, []);
				}

				for (const result of results) {
					const file = xlsx.read(result, {
						cellDates: true,
						cellNF: false,
						cellText: false
					});

					const sheetNames = file.SheetNames;
					const totalSheets = sheetNames.length;

					// Loop through sheets
					for (let i = 0; i < totalSheets; i++) {
						// Convert to json using xlsx
						let tempData = xlsx.utils.sheet_to_json(file.Sheets[sheetNames[i]]);
						parsedData.push(...tempData);
					}
				}

				if (parsedData.length) {
					parsedData = parsedData.map((x) => ({
						...x,
						EventTime: converExcelDateToUTC(x.EventTime)
					}));
				}

				for (const pd of parsedData) {
					markActive(pd, parsedData);
				}

				const filteredData = parsedData.filter(
					(x) => x.EventTime >= starttimeStamp && x.EventTime <= endtimeStamp
				);

				return cb(
					null,
					filteredData.sort((a, b) => (a.EventTime > b.EventTime ? 1 : -1))
				);
			}
		} catch (e) {
			return cb(e);
		}
	}
}

const converExcelDateToUTC = (datetime) => {
	const d = new Date(datetime);
	let dtOffset = new Date(d.setMinutes(d.getMinutes() - d.getTimezoneOffset()));
	return dtOffset.getTime();
};

const markActive = (record, dataset) => {
	const findRecords = dataset.filter(
		(x) =>
			x.Source === record.Source && x.LogType === record.LogType && x.FailureID === record.FailureID
	);

	if (findRecords.length > 1) {
		for (let i = 1; i < findRecords.length; i++) {
			// skip first record so i=1
			if (findRecords[0].FailureState === true && findRecords[i].FailureState === false) {
				findRecords[i].FailureState = false;
			} else if (findRecords[0].FailureState === false && findRecords[i].FailureState === true) {
				findRecords[i].FailureState = false;
			} else if (findRecords[0].FailureState === true && findRecords[i].FailureState === true) {
				findRecords[i].FailureState = true;
			} else {
				// false false scenario
				findRecords[i].FailureState = false;
			}
		}
	}
};

module.exports = AlarmeventQuery;
