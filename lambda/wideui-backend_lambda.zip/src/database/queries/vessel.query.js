/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const CommonQuery = require("./common.query");

class VesselQuery {
	constructor() {}

	static postVesselsByIMO(imo, cb) {
		let query;
		let param;
		if (imo?.length === 1 && imo.includes(-1)) {
			query = `SELECT 
                                t1.id, 
                                t1.imo,
                                t1.ship_name, 
                                t1.type,
                                CASE
                                        WHEN t1.EMS_1 = 0 THEN null
                                        WHEN t1.EMS_1 = 1 THEN "Diesel UNIC"
                                        WHEN t1.EMS_1 = 2 THEN "DF UNIC"
                                        WHEN t1.EMS_1 = 3 THEN "Diesel WECS"
                                        WHEN t1.EMS_1 = 4 THEN "DF WECS"
                                        WHEN t1.EMS_1 = 5 THEN "Diesel WICE"
                                        WHEN t1.EMS_1 = 6 THEN "DF WICE"
                                        END as ems1,
                                CASE
                                        WHEN t1.EMS_2 = 0 THEN null
                                        WHEN t1.EMS_2 = 1 THEN "Diesel UNIC"
                                        WHEN t1.EMS_2 = 2 THEN "DF UNIC"
                                        WHEN t1.EMS_2 = 3 THEN "Diesel WECS"
                                        WHEN t1.EMS_2 = 4 THEN "DF WECS"
                                        WHEN t1.EMS_2 = 5 THEN "Diesel WICE"
                                        WHEN t1.EMS_2 = 6 THEN "DF WICE"
                                        END as ems2,
                                t1.engine_type, 
                                t1.flag, 
                                t1.owner_id, 
                                t1.dbnumber,
                                t2.owner_name 
                            FROM 
                                wingd.evt_ships as t1
                            INNER JOIN 
                                wingd.evt_owners as t2 
                            ON 
                                t1.owner_id = t2.id
                                `;
			param = [];
		} else {
			query = `SELECT 
                                t1.id, 
                                t1.imo, 
                                t1.ship_name, 
                                t1.type,
                                CASE
                                        WHEN t1.EMS_1 = 0 THEN null
                                        WHEN t1.EMS_1 = 1 THEN "Diesel UNIC"
                                        WHEN t1.EMS_1 = 2 THEN "DF UNIC"
                                        WHEN t1.EMS_1 = 3 THEN "Diesel WECS"
                                        WHEN t1.EMS_1 = 4 THEN "DF WECS"
                                        WHEN t1.EMS_1 = 5 THEN "Diesel WICE"
                                        ELSE "DF WICE"
                                        END as ems1,
                                CASE
                                        WHEN t1.EMS_2 = 0 THEN null
                                        WHEN t1.EMS_2 = 1 THEN "Diesel UNIC"
                                        WHEN t1.EMS_2 = 2 THEN "DF UNIC"
                                        WHEN t1.EMS_2 = 3 THEN "Diesel WECS"
                                        WHEN t1.EMS_2 = 4 THEN "DF WECS"
                                        WHEN t1.EMS_2 = 5 THEN "Diesel WICE"
                                        ELSE "DF WICE"
                                        END as ems2,
                                t1.engine_type, 
                                t1.flag, 
                                t1.owner_id, 
                                t1.dbnumber,
                                t2.owner_name 
                            FROM 
                                wingd.evt_ships as t1
                            INNER JOIN 
                                wingd.evt_owners as t2 
                            ON 
                                t1.owner_id = t2.id
                            WHERE 
                                imo IN (?) 
                            ORDER BY 
                                t1.owner_id `;
			param = imo;
		}

		CommonQuery.excecuteQuery(query, param, cb);
	}

	static getVesselLoadParams(vesselList, cb) {
		vesselList = vesselList.filter((x) => x.imo !== 505050 && x.imo !== 8269773); // to be deleted later
		let query = "";
		for (let i = 0; i < vesselList.length; i++) {
			if (i !== 0) {
				query = query + " UNION ALL ";
			}

			query =
        query +
        ` SELECT 
                                    ${vesselList[i].imo} as imo, 
                                    otVal1 as nom_power_cmcr, 
                                    otVal2 as mom_revolution 
                               FROM 
                                    wingd_${vesselList[i].owner_id}_eds.engineotherdata_${vesselList[i].imo}
                               WHERE 
                                    eng_number=1 AND tier=2`;
		}

		CommonQuery.excecuteQuery(query, [], cb);
	}
}

module.exports = VesselQuery;
