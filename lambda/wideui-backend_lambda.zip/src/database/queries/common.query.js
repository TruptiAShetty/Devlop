/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");

class CommonQuery {
	static getOwnerId(imo, cb) {
		const sqlQuery = `SELECT
                                t1.imo,
                                t1.owner_id,
                                t1.dbnumber
                           FROM 
                                wingd.evt_ships as t1
                           WHERE 
                                t1.imo IN (?)
                            `;

		this.excecuteQuery(sqlQuery, imo, cb);
	}

	// @desc      get col_name where signalname = "something" & tablename="something"
	static getColumnName(payload, cb) {
		let query = "";

		for (let i = 0; i < payload.length; i++) {
			console.log(payload[i].signalname);
			if (i !== 0) {
				query = query + " Union All";
			}

			for (let j = 0; j < payload[i]?.signals.length; j++) {
				if (j !== 0) {
					query = query + " Union All";
				}

				query =
          query +
          ` SELECT
                                    ${payload[i].owner_id} as owner_id, 
                                    ${payload[i].imo} as imo, 
                                    nameAtSource, 
                                    col_name, 
                                    groupName,
                                    description,
									rangeMin,
									rangeMax
                          FROM 
                                    wingd.evt_signals_names
                          WHERE 
                                    nameAtSource = ${mysql.escape(payload[i].signals[j].signalname)}
                                    AND 
                                    groupName = ${mysql.escape(payload[i].signals[j].source)}`;
			}
		}
		this.excecuteQuery(query, [], cb);
	}

	static excecuteQuery(query, param, cb) {
		mysql.query(query, [param], (error, results) => {
			if (error) {
				return cb(error);
			}
			return cb(null, results);
		});
	}
}

module.exports = CommonQuery;
