/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");

class FavoritesGetQuery {
	constructor() {}

	// @desc      get all favourites data
	static favget = async (payload, cb) => {
		console.log("payload:", payload);
		const favoriteName = payload.favorite_name;
		const userId= payload.user_id;
		let query;
		if (favoriteName) {
			query = `SELECT *FROM wide_ui_config.favourites WHERE favorite_name="${favoriteName}" and user_id="${userId}";`;
		} else {
			query = `SELECT *FROM wide_ui_config.favourites WHERE user_id="${userId}";`;
		}

		let queries = [];
		queries.push(query);
		console.log("queries:", queries);
		try {
			const queryResults = await Promise.all(
				queries.map(async (query) => {
					return new Promise((resolve, reject) =>
						mysql.query(query, [], (err, result) => {
							if (err) {
								return reject(err);
							} else {
								const separeteQueryResult = [];
								for (const r of result) {
									if (typeof r === "string") {
										separeteQueryResult.push(JSON.parse(r));
									} else {
										separeteQueryResult.push(r);
									}
								}
								return resolve(separeteQueryResult);
							}
						})
					);
				})
			);
			return cb(null, queryResults[0]);
		} catch (e) {
			return cb(e);
		}
	};
}

module.exports = FavoritesGetQuery;
