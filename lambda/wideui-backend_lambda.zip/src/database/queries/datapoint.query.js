/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");
const DATAPOINT_CONSTANTS = require("../../core/constants/datapoint.constants");

class DatapointQuery {
	constructor() { }

	// @desc      get datapoint for each signal and transform it to appropriate json result
	// fetching resolution(autoloading,fixed down/up sampling) data -- based on sampling rate
	static datapoints = async (payload, cb) => {
		console.log("datapoint payload:", payload);

		const isDownloadAPI = payload.isDownloadAPI; //this flag for only download API
		let { starttime, endtime,vessels,resolutionRate } = payload;

		let date_format;
		if (payload.resolution === DATAPOINT_CONSTANTS.FIXED_1SECOND) {
			date_format = '%Y-%m-%d %H:%i:%S'
		}
		if (payload.resolution === DATAPOINT_CONSTANTS.FIXED_1MIN) {
			date_format = '%Y-%m-%d %H:%i'
		}
		if (payload.resolution === DATAPOINT_CONSTANTS.FIXED_1HOUR) {
			date_format = '%Y-%m-%d %H'
		}

		const queries = [];

		for (let i = 0; i < vessels.length; i++) {
			for (let j = 0; j < vessels[i].signals.length; j++) {
				let mysqlQuery = " SELECT json_arrayagg(obj) as RESULT FROM (";
				for (let k = 0; k < vessels[i].signals[j].col_name.length; k++) {
					if (k !== 0) {
						mysqlQuery = mysqlQuery + " UNION ALL";
					}

					let signal_name = vessels[i].signals[j].nameAtSource[k];
					const rangeMax = vessels[i].signals[j].rangeMax[k];
					const rangeMin = vessels[i].signals[j].rangeMin[k];
					const signal_col_name = vessels[i].signals[j].col_name[k];
					const groupName = vessels[i].signals[j].groupName;
					let csv_signal_name = vessels[i].imo + "." + groupName + "." + signal_name;
					let datapointQuery;
					if (isDownloadAPI) {
						datapointQuery = `json_object(
                            "imo",${vessels[i].imo},
                            "owner_id", ${vessels[i].owner_id},
                            "csv_signal_name","${csv_signal_name}",
                            "signalName", "${signal_name}", 
                            "source", "${groupName}",
                            "datapoints", json_arrayagg(json_object(
                              "datetime",signaldate, 
                              "${csv_signal_name}",${signal_col_name}
                              ))                                   
                            ) AS obj`
					} else {
						datapointQuery = `json_object(
                            "imo",${vessels[i].imo},
                            "owner_id", ${vessels[i].owner_id},
                            "signalName", "${signal_name}", 
                            "source", "${groupName}",
                            "datapoints", json_arrayagg(json_array(
                                UNIX_TIMESTAMP(signaldate)*1000, 
                                ${signal_col_name}
                              ))                                   
                            ) AS obj`
					}
					
					let query;
					if (payload.resolution === DATAPOINT_CONSTANTS.AUTOLOADING_SINGLESAMPLE) {
						query = ` SELECT ${datapointQuery}
								FROM 
									wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName} 
								WHERE
									(signaldate between ${mysql.escape(starttime)} AND ${mysql.escape(endtime)}) AND (id % ${resolutionRate}  = 1)
									AND (${signal_col_name} > ${rangeMin} AND ${signal_col_name} < ${rangeMax})
								`;
					} else if (payload.resolution === DATAPOINT_CONSTANTS.AUTOLOADING_AVG) {
						query = ` SELECT ${datapointQuery}
						FROM 
							(
								SELECT signaldate,AVG(${signal_col_name}) AS ${signal_col_name}
								FROM wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName}
								where signaldate between ${mysql.escape(starttime)} AND ${mysql.escape(endtime)}
								AND (${signal_col_name} > ${rangeMin} AND ${signal_col_name} < ${rangeMax})
								GROUP BY CEIL(id / ${resolutionRate})
							) y
						`;
					} else if (payload.resolution === DATAPOINT_CONSTANTS.RAW) {
							query = ` SELECT ${datapointQuery}
                        FROM 
                            wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName} 
                        WHERE
                            signaldate between ${mysql.escape(starttime)} AND ${mysql.escape(endtime)}
                        `;
					} else {
						query = ` SELECT ${datapointQuery}
								FROM 
								(
									SELECT date_format(signaldate, '${date_format}') AS signaldate,AVG(${signal_col_name}) AS ${signal_col_name}
									FROM wingd_${vessels[i].owner_id}.evt_${vessels[i].imo}_${groupName} 
									WHERE signaldate between ${mysql.escape(starttime)} AND ${mysql.escape(endtime)}
									GROUP BY date_format(signaldate, '${date_format}')
								) y 
								`;
					}
					mysqlQuery = mysqlQuery + query;
				}

				mysqlQuery = mysqlQuery + ") x ";
				queries.push(mysqlQuery);
			}
		}
		try {
			const queryResults = await Promise.all(
				queries.map(async (query) => {
					return new Promise((resolve, reject) =>
						mysql.query(query, [], (err, result) => {
							if (err) {
								return reject(err);
							} else {
								const separeteQueryResult = [];
								result = JSON.parse(result[0].RESULT);
								for (const r of result) {
									if (typeof r === "string") {
										separeteQueryResult.push(JSON.parse(r));
									} else {
										separeteQueryResult.push(r);
									}
								}
								return resolve(separeteQueryResult);
							}
						})
					);
				})
			);
			return cb(null, queryResults);
		} catch (e) {
			return cb(e);
		}
	};
}

module.exports = DatapointQuery;
