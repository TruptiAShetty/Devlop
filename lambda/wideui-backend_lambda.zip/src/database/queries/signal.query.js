/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");
const CommonQuery = require("./common.query");

class SignalQuery {
	constructor() {}

	static getSignals(payload, cb) {
		let query = "";

		console.log("payload", payload);

		for (let i = 0; i < payload.length; i++) {
			if (i !== 0) {
				query = query + " union all ";
			}

			let sqlQueryTemplate = ` SELECT 
                                    ${payload[i].owner_id} as owner_id,
                                    COALESCE(nameAtSource, col_name) as name,
                                    description, 
                                    unit,  
                                    rangeMin, 
                                    rangeMax, 
                                    WESN.groupName,
                                    ${payload[i].imo} as imo,

                                    (SELECT 
                                        dbnumber 
                                     FROM 
                                        wingd.evt_ships 
                                     WHERE 
                                        imo=${mysql.escape(payload[i].imo)}
                                    ) as enginenumber,

                                    (SELECT 
                                         CASE LOCATE(',', dbnumber) 
                                            WHEN 0 THEN 'Single'
                                            ELSE 'Twin'
                                         END
                                    FROM 
                                       wingd.evt_ships 
                                     WHERE 
                                      imo=${mysql.escape(payload[i].imo)}
                                    ) as ENGINE_COUNT,

                                    (SELECT
                                      CASE ENGINE_COUNT 
                                          WHEN 'Single' then ems_1
                                          WHEN 'Twin' then ems_2
                                          ELSE 'INVALID'                
                                      END  
                                     FROM 
                                        wingd.evt_ships 
                                     WHERE 
                                        imo=${mysql.escape(payload[i].imo)}
                                    ) as ENGINE_TYPE,

                                    (SELECT
                                       CASE ENGINE_TYPE 
                                         WHEN 0 THEN null
                                         WHEN 1 THEN "Diesel"
                                         WHEN 2 THEN "DF"
                                         WHEN 3 THEN "Diesel"
                                         WHEN 4 THEN "DF"
                                         WHEN 5 THEN "Diesel"
                                         WHEN 6 THEN "DF"
                                         ELSE 'INVALID'                
                                       END 
                                    ) as FUEL_TYPE,
                                 
                                    (SELECT
                                         CASE ENGINE_TYPE  
                                            WHEN 0 THEN null
                                            WHEN 1 THEN "UNIC"
                                            WHEN 2 THEN "UNIC"
                                            WHEN 3 THEN "WECS"
                                            WHEN 4 THEN "WECS"
                                            WHEN 5 THEN "WICE"
                                            WHEN 6 THEN "WICE"
                                            ELSE 'INVALID'                
                                          END
                                    ) as CONTROL_SYSTEM,
      
                                    (SELECT 
                                      CONCAT(CONTROL_SYSTEM, '_', ENGINE_COUNT)
                                    ) as CONTROL_SYSTEM_WITH_ENGINE_COUNT,

                                    (SELECT
                                      CONCAT(CONTROL_SYSTEM_WITH_ENGINE_COUNT, '_', FUEL_TYPE)
                                    ) as CONTROL_SYSTEM_WITH_FULE_TYPE,
                                    
                                    (SELECT  
                                        CASE  CONTROL_SYSTEM_WITH_FULE_TYPE
                                           
                                            WHEN 'WICE_Single_Diesel' THEN	WSR.WICE_Diesel
                                            WHEN 'WICE_Single_DF'     THEN	WSR.WICE_DF
                                            WHEN 'WICE_Twin_Diesel'   THEN	WSR.WICE_Twin
                                            WHEN 'WICE_Twin_DF'       THEN	WSR.WICE_Twin
                                              
                                            WHEN 'UNIC_Single_Diesel' THEN	WSR.UNIC_Single
                                            WHEN 'UNIC_Single_DF'     THEN	WSR.UNIC_Single
                                            WHEN 'UNIC_Twin_Diesel'   THEN	WSR.UNIC_Twin
                                            WHEN 'UNIC_Twin_DF'       THEN	WSR.UNIC_Twin
                                              
                                            WHEN 'WECS_Single_Diesel' THEN	WSR.WECS_Single
                                            WHEN 'WECS_Single_DF'     THEN	WSR.WECS_Single
                                            WHEN 'WECS_Twin_Diesel'   THEN	WSR.WECS_Twin
                                            WHEN 'WECS_Twin_DF'       THEN	WSR.WECS_Twin
                                            
                                            ELSE 'INVALID'                
                                          END
                                      ) AS ENABLED 

                                    FROM 
                                      wingd.evt_signals_names as WESN

                                    INNER JOIN wide_ui_config.signal_rule as WSR                    
                                      
                                    USING (groupName)
                                    `;

			query = query + sqlQueryTemplate;

			if (!payload[i].signals.length) {
				query = query + " HAVING ENABLED ";
			} else {
				for (let j = 0; j < payload[i].signals.length; j++) {
					query =
            query +
            ` WHERE WESN.nameAtSource=${mysql.escape(payload[i].signals[j].signalname)} 
          AND WESN.groupName = ${mysql.escape(payload[i].signals[j].source)} 
          HAVING ENABLED `;

					if (j !== payload[i].signals.length - 1) {
						query = query + " UNION ALL" + sqlQueryTemplate;
					}
				}
			}
		}

		CommonQuery.excecuteQuery(query, [], cb);
	}
}

module.exports = SignalQuery;
