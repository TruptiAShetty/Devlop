/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("../db");

class FavoriteAddQuery {
	constructor() {}

	// @desc      add new favourite
	static favadd = async (payload, cb) => {
		console.log("insert records:", payload);

		//@des creating table for storing favourites
		let queries = [];
		let query = "SELECT *FROM wide_ui_config.favourites";

		//@des this query will check if table is exist or not
		queries.push(query);
		try {
			const queryResults = await Promise.all(
				queries.map(async (query) => {
					return new Promise((resolve, reject) =>
						mysql.query(query, [], (err, result) => {
							if (err) {
								queries = [];
								console.log("table create");
								query =
                  "CREATE TABLE wide_ui_config.favourites (id int NOT NULL AUTO_INCREMENT,user_id VARCHAR(50),favorite_name VARCHAR(50),vessels JSON,PRIMARY KEY (id));";
								queries.push(query);
							} else {
								queries = [];
							}
							return resolve(true);
						})
					);
				})
			);
		} catch (e) {
			return cb(e);
		}

		console.log("create records");
		console.log(queries);
		//@des inserting data into table
		queries.push(query);
		query = "INSERT INTO wide_ui_config.favourites (user_id,favorite_name,vessels) VALUES ?;";
		queries.push(query);
		try {
			const queryResults = await Promise.all(
				queries.map(async (query) => {
					return new Promise((resolve, reject) =>
						mysql.query(query, [payload], (err, result) => {
							if (err) {
								console.log("error query", query);
								return reject(err);
							} else {
								return resolve({ message: "data inserted successfully" });
							}
						})
					);
				})
			);
			return cb(null, queryResults);
		} catch (e) {
			return cb(e);
		}
	};
}

module.exports = FavoriteAddQuery;
