/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

const mysql = require("../db");

class FavoriteUpdateQuery {
    constructor() { }

    // @desc      updating favoute metadata
    static favUpdate = async (payload,favObj,userId, cb) => {
        console.log("fav update payload", payload);
        const favoriteName = favObj.favorite_name;
        console.log("fav name", favoriteName);
        const oldFavoriteName = favObj.old_favorite_name;
        let vessels = JSON.stringify(payload);
        let query;
        if(oldFavoriteName){
            query = `UPDATE wide_ui_config.favourites SET favorite_name='${favoriteName}', vessels='${vessels}' where favorite_name='${oldFavoriteName}' and user_id='${userId}';`
        }else{
            query = `UPDATE wide_ui_config.favourites SET vessels='${vessels}' where favorite_name='${favoriteName}' and user_id='${userId}';`
        }
        mysql.query(query, function(err, result) {
            if (err) throw err;
            console.log("Favorite updated successfully");
            return cb(null, [{ message: "Favorite updated successfully" }]);
        })
    };
}

module.exports = FavoriteUpdateQuery;