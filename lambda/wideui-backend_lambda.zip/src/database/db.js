/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const mysql = require("mysql");
const config = require("../core/config/config.json");

const db = mysql.createPool({
	host: config.mysql.host,
	port: config.mysql.port,
	user: config.mysql.user,
	password: config.mysql.password
});

// const keepAlive = () => {
db.getConnection((err, connection) => {
	if (err) {
		console.error(err);
		return;
	}
	connection.ping();
	connection.release();
	console.log("Database connected !");
});
// }

// keepAlive();

// setInterval(keepAlive, 30000);

module.exports = db;
