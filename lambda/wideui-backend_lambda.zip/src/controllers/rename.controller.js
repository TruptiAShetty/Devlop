/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const FavoriteUpdateQuery = require("../database/queries/favoriteupdate.query");
const CommonQuery = require("../database/queries/common.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const renameFavouriteDataValidator = require("../validators/rename-fav-validator");
const FavoritesGetQuery = require("../database/queries/favouriteget.query");
const utils = require("../core/utility/common.utils");
const { reset } = require("nodemon");
// @desc      add renamed favorite and delete existing one
// @route     POST /api/v2.1/rename
// @access    Private
exports.renameFavorite = (req, res, next) => {
	console.log("postAddFavorite controller", req.body);

	let { starttime, endtime,user_id ,favorite_name,old_favorite_name, vessels } = req.body;
	let payload = req.body;
	//@des request data validator
	const errorResponse = renameFavouriteDataValidator(req, res, next);
	if (errorResponse?.statusCode !== 200) {
		return next(errorResponse);
	}

	starttime = new Date(starttime).toISOString();
	endtime = new Date(endtime).toISOString();
	const imo = vessels.map(x => x.imo);

	// @desc      first get owner_id for each IMO
	CommonQuery.getOwnerId(imo, (error, result) => {
		console.log("owner result", result);

		if (error) {
			next(error);
			return;
		}
		let message = ERROR_MSG.IMO_NOT_FOUND;
		if (!result?.length) {
			if(imo.length>1){
				message = ERROR_MSG.IMOS_NOT_FOUND;
			}
			return res.status(404).send({imo:imo,message:message})
		}

		let invalidImos = [];
		let isImoExists;
		if (result?.length) {
			imo.map((x) => {
				isImoExists = result.find((t) => parseInt(t.imo) === x);
				if(!isImoExists){
					invalidImos.push(x);
				}
			});
		}
		if(invalidImos.length){
			if(invalidImos.length>1){
				message = ERROR_MSG.IMOS_NOT_FOUND;
			}
			return res.status(404).send({imo:invalidImos,message:message})
		}

		if (result.length) {
			vessels = vessels.map((x) => {
				x.owner_id = result.find((t) => parseInt(t.imo) === x.imo).owner_id;
				return x;
			});
		}
		// @desc      validating signal names before pushing to database
		let signalNames = utils.getSinalNames(vessels);
		CommonQuery.getColumnName(vessels, (error, result) => {
			if (error) {
				next(error);
				return;
			}

			if (!result?.length) {
				return res.status(404).send({ signals: signalNames, message: ERROR_MSG.SIGNAL_NOT_FOUND })
			}
			let invalidSignals = [];
			let isSignalExists;
			if (result.length) {
				signalNames.forEach((x) => {
					isSignalExists = result.find((t) => t.nameAtSource === x);
					if (!isSignalExists) {
						invalidSignals.push(x);
					}
				});
			}
			message = ERROR_MSG.SIGNAL_NOT_FOUND
			if (invalidSignals.length) {
				if (invalidSignals.length > 1) {
					message = ERROR_MSG.SIGNALS_NOT_FOUND;
				}
				return res.status(404).send({ signals: invalidSignals, message: message })
			}
			FavoritesGetQuery.favget(payload, (error, result) => {
				if (error) {
					next(error);
					return;
				}
				vessels.map(x => {
					x.starttime = starttime;
					x.endtime = endtime;
				});
				let favObj = {}
				favObj.favorite_name = favorite_name;
				favObj.old_favorite_name = old_favorite_name;
				if (result.length > 0) {
					return res.status(400).send({ message: "Favorite name already exists" });
				} else {
					FavoriteUpdateQuery.favUpdate(vessels, favObj, user_id, (error, result) => {
						if (error) {
							next(error);
							return;
						}
						return res.status(200).send({ message: "Favorite updated successfully.." });
					});
				}
			});
			
		})
	});
};