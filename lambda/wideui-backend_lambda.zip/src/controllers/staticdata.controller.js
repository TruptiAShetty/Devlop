/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const StaticdataQuery = require("../database/queries/staticdata.query");
const CommonQuery = require("../database/queries/common.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const SPLIT_ENGINE_NUNBER = require("../core/utility/split-engine-number");

// @desc      Get staticdata for given params
// @route     POST /api/v2.1/staticdata
// @access    Private
exports.postStaticdata = (req, res, next) => {
	const { imo, enginenumber, dataset, param } = req.body;

	let eng_number = 1;

	if (!imo) {
		return next(new ErrorResponse("imo is required !", 400));
	}

	if (!enginenumber) {
		return next(new ErrorResponse("enginenumber is required !", 400));
	}

	if (!dataset) {
		return next(new ErrorResponse("dataset is required !", 400));
	}

	if (!param && !param?.length) {
		return next(new ErrorResponse("param is required !", 400));
	}

	CommonQuery.getOwnerId(imo, (error, result) => {
		if (error) {
			return next(error);
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		for (const record of result) {
			const splitEnginenumber = SPLIT_ENGINE_NUNBER(record.dbnumber);
			if (splitEnginenumber.length) {
				const findIndex = splitEnginenumber.findIndex((x) => x === enginenumber);
				switch (findIndex) {
				case 0:
					eng_number = 1;
					break;
				case 1:
					eng_number = 2;
					break;
				default:
					eng_number = 1;
					break;
				}
			}
		}

		StaticdataQuery.postStaticdata(
			imo,
			result[0].owner_id,
			enginenumber,
			eng_number,
			dataset,
			param,
			(error, result) => {
				if (error) {
					return next(error);
				}

				if (!result?.length) {
					return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
				}

				const finalResult = [];
				for (const record of result) {
					const tempRecord = record;
					tempRecord.imo = imo;
					tempRecord.enginenumber = enginenumber;
					const tempResult = JSON.parse(record[dataset]);
					tempRecord[dataset] = [];
					for (const r of tempResult) {
						if (typeof r === "string") {
							tempRecord[dataset].push(JSON.parse(r));
						} else {
							if (r !== null) {
								tempRecord[dataset].push(r);
							}
						}
					}
					finalResult.push(tempRecord);
				}

				return res.status(200).send(finalResult);
			}
		);
	});
};
