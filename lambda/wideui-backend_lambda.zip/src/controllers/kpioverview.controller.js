/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
// @desc      Get kpi over view data for signal(s)
// @route     POST /api/v2.1/kpioverview
// @access    Private

exports.postKpioverview = (req, res, next) => {
    const kpi_data = [{

        IMO: "8999748",
        ShipName: "Sinnary",

        EngineType: "12x92DF",

        EngineKPI: "45.3%",

        Cylinder1: "45%",

        Cylinder2: "35%",

        Turbine1: "45%",

        Turbine2: "35%",

        ServoOil: "202.0",

        FuelInjection: "605.0",

        ScavengeAir: "2.00"

    },

    {
        IMO: "8999748",
        ShipName: "Camel Twin",

        EngineType: "15x92DF",

        EngineKPI: "34.3%",

        Cylinder1: "55%",

        Cylinder2: "25%",

        Turbine1: "95%",

        Turbine2: "65%",

        ServoOil: "200.0",

        FuelInjection: "555.0",

        ScavengeAir: "5.00"

    },

    {
        IMO: "8269772",
        ShipName: "Montamare",

        EngineType: "16x42DF",

        EngineKPI: "50%",

        Cylinder1: "10%",

        Cylinder2: "75%",

        Turbine1: "98%",

        Turbine2: "43%",

        ServoOil: "500.0",

        FuelInjection: "329.0",

        ScavengeAir: "1.00"

    },

    {
        IMO: "1819839",
        ShipName: "Lovre",

        EngineType: "11x62DF",

        EngineKPI: "10%",

        Cylinder1: "23%",

        Cylinder2: "84%",

        Turbine1: "58%",

        Turbine2: "83%",

        ServoOil: "240.0",

        FuelInjection: "589.0",

        ScavengeAir: "7.00"

    },

    {
        IMO: "1819839",
        ShipName: "shipname1",

        EngineType: "5x65B",

        EngineKPI: "37%",

        Cylinder1: "73%",

        Cylinder2: "34%",

        Turbine1: "18%",

        Turbine2: "43%",

        ServoOil: "340.0",

        FuelInjection: "189.0",

        ScavengeAir: "4.00"

    },

    {
        IMO: "1819839",
        ShipName: "shipname2",

        EngineType: "5x65B",

        EngineKPI: "95%",

        Cylinder1: "33%",

        Cylinder2: "94%",

        Turbine1: "88%",

        Turbine2: "33%",

        ServoOil: "940.0",

        FuelInjection: "389.0",

        ScavengeAir: "3.00"

    },

    {
        IMO: "8269772",
        ShipName: "shipname1",

        EngineType: "5x65B",

        EngineKPI: "37%",

        Cylinder1: "73%",

        Cylinder2: "34%",

        Turbine1: "18%",

        Turbine2: "43%",

        ServoOil: "340.0",

        FuelInjection: "189.0",

        ScavengeAir: "4.00"

    },

    {
        IMO: "1819839",
        ShipName: "Lovre",

        EngineType: "11x62DF",

        EngineKPI: "10%",

        Cylinder1: "23%",

        Cylinder2: "84%",

        Turbine1: "58%",

        Turbine2: "83%",

        ServoOil: "240.0",

        FuelInjection: "589.0",

        ScavengeAir: "6.00"

    },

    {
        IMO: "8269772",
        ShipName: "Montamare",

        EngineType: "16x42DF",

        EngineKPI: "50%",

        Cylinder1: "10%",

        Cylinder2: "75%",

        Turbine1: "98%",

        Turbine2: "43%",

        ServoOil: "500.0",

        FuelInjection: "329.0",

        ScavengeAir: "1.00"

    },

    {
        IMO: "1819839",
        ShipName: "Sinnary",

        EngineType: "12x92DF",

        EngineKPI: "45.3%",

        Cylinder1: "45%",

        Cylinder2: "35%",

        Turbine1: "45%",

        Turbine2: "35%",

        ServoOil: "202.0",

        FuelInjection: "605.0",

        ScavengeAir: "2.00"

    },

    {
        IMO: "8269772",
        ShipName: "shipname1",

        EngineType: "5x65B",

        EngineKPI: "37%",

        Cylinder1: "73%",

        Cylinder2: "34%",

        Turbine1: "18%",

        Turbine2: "43%",

        ServoOil: "340.0",

        FuelInjection: "189.0",

        ScavengeAir: "4.00"

    },

    {
        IMO: "505050",
        ShipName: "shipname1",

        EngineType: "5x65B",

        EngineKPI: "37%",

        Cylinder1: "73%",

        Cylinder2: "34%",

        Turbine1: "18%",

        Turbine2: "43%",

        ServoOil: "340.0",

        FuelInjection: "189.0",

        ScavengeAir: "4.00"

    },

    {
        IMO: "8269772",
        ShipName: "Lovre",

        EngineType: "11x62DF",

        EngineKPI: "10%",

        Cylinder1: "23%",

        Cylinder2: "84%",

        Turbine1: "58%",

        Turbine2: "83%",

        ServoOil: "240.0",

        FuelInjection: "589.0",

        ScavengeAir: "7.00"

    },

    {
        IMO: "505050",
        ShipName: "Camel Twin",

        EngineType: "15x92DF",

        EngineKPI: "34.3%",

        Cylinder1: "55%",

        Cylinder2: "25%",

        Turbine1: "95%",

        Turbine2: "65%",

        ServoOil: "200.0",

        FuelInjection: "555.0",

        ScavengeAir: "5.00"

    },

    {
        IMO: "8269772",
        ShipName: "Lovre",

        EngineType: "11x62DF",

        EngineKPI: "10%",

        Cylinder1: "23%",

        Cylinder2: "84%",

        Turbine1: "58%",

        Turbine2: "83%",

        ServoOil: "240.0",

        FuelInjection: "589.0",

        ScavengeAir: "9.00"

    },

    {
        IMO: "505050",
        ShipName: "Montamare",

        EngineType: "16x42DF",

        EngineKPI: "50%",

        Cylinder1: "10%",

        Cylinder2: "75%",

        Turbine1: "98%",

        Turbine2: "43%",

        ServoOil: "500.0",

        FuelInjection: "329.0",

        ScavengeAir: "1.00"

    },

    {
        IMO: "8269772",
        ShipName: "Sinnary",

        EngineType: "12x92DF",

        EngineKPI: "45.3%",

        Cylinder1: "45%",

        Cylinder2: "35%",

        Turbine1: "45%",

        Turbine2: "35%",

        ServoOil: "202.0",

        FuelInjection: "605.0",

        ScavengeAir: "2.00"

    },

    {
        IMO: "1819839",
        ShipName: "shipname1",

        EngineType: "5x65B",

        EngineKPI: "37%",

        Cylinder1: "73%",

        Cylinder2: "34%",

        Turbine1: "18%",

        Turbine2: "43%",

        ServoOil: "340.0",

        FuelInjection: "189.0",

        ScavengeAir: "4.00"

    },

    {
        IMO: "8269772",
        ShipName: "shipname1",

        EngineType: "5x65B",

        EngineKPI: "37%",

        Cylinder1: "73%",

        Cylinder2: "34%",

        Turbine1: "18%",

        Turbine2: "43%",

        ServoOil: "340.0",

        FuelInjection: "189.0",

        ScavengeAir: "4.00"

    },

    {
        IMO: "1819839",
        ShipName: "Lovre",

        EngineType: "11x62DF",

        EngineKPI: "10%",

        Cylinder1: "23%",

        Cylinder2: "84%",

        Turbine1: "58%",

        Turbine2: "83%",

        ServoOil: "240.0",

        FuelInjection: "589.0",

        ScavengeAir: "7.00"

    },

    {
        IMO: "8269772",
        ShipName: "Camel Twin",

        EngineType: "15x92DF",

        EngineKPI: "34.3%",

        Cylinder1: "55%",

        Cylinder2: "25%",

        Turbine1: "95%",

        Turbine2: "65%",

        ServoOil: "200.0",

        FuelInjection: "555.0",

        ScavengeAir: "5.00"

    },

    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "1819839",
        ShipName: "Camel Twin",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },
    {
        IMO: "8999748",
        ShipName: "Sinnary",
        EngineType: "12x92DF",
        EngineKPI: "45.3%",
        Cylinder1: "45%",
        Cylinder2: "35%",
        Turbine1: "45%",
        Turbine2: "35%",
        ServoOil: "202.0",
        FuelInjection: "605.0",
        ScavengeAir: "2.00"
    },

    ]
    res.status(200).send(kpi_data);
};