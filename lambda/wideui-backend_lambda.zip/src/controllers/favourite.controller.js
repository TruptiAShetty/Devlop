/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const FavoriteAddQuery = require("../database/queries/favouriteadd.query");
const FavoriteUpdateQuery = require("../database/queries/favoriteupdate.query");
const CommonQuery = require("../database/queries/common.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const getFavResponse = require("../core/model-builder/response/favourite-response-model-builder.js");
const validator = require("../validators/favourite-common-validator");
const FavoriteDeleteQuery = require("../database/queries/favouritedelete.query");
const FavoritesGetQuery = require("../database/queries/favouriteget.query");
const SignalQuery = require("../database/queries/signal.query");
const utils = require("../core/utility/common.utils");
const { reset } = require("nodemon");
// @desc      add favorites for vessels
// @route     POST /api/v2.1/favorite
// @access    Private
exports.addFavourite = (req, res, next) => {
	console.log("postAddFavorite controller", req.body);

	const payload = req.body;
	let { starttime, endtime, user_id, favorite_name, vessels } = req.body;
	//@des request data validator
	const errorResponse = validator.favouriteDataValidator(req, res, next);
	if (errorResponse?.statusCode !== 200) {
		return next(errorResponse);
	}
	starttime = new Date(starttime).toISOString();
	endtime = new Date(endtime).toISOString();
	const imo = vessels.map((x) => x.imo);
	// @desc      first get owner_id for each IMO
	CommonQuery.getOwnerId(imo, (error, result) => {
		console.log("owner result", result);

		if (error) {
			next(error);
			return;
		}
		let message = ERROR_MSG.IMO_NOT_FOUND;
		if (!result?.length) {
			if(imo.length>1){
				message = ERROR_MSG.IMOS_NOT_FOUND;
			}
			return res.status(404).send({imo:imo,message:message})
		}

		let invalidImos = [];
		let isImoExists;
		if (result?.length) {
			imo.map((x) => {
				isImoExists = result.find((t) => parseInt(t.imo) === x);
				if(!isImoExists){
					invalidImos.push(x);
				}
			});
		}
		if(invalidImos.length){
			if(invalidImos.length>1){
				message = ERROR_MSG.IMOS_NOT_FOUND;
			}
			return res.status(404).send({imo:invalidImos,message:message})
		}

		if (result.length) {
			vessels = vessels.map((x) => {
				x.owner_id = result.find((t) => parseInt(t.imo) === x.imo).owner_id;
				return x;
			});
		}
		// @desc      validating signal names before pushing to database
		let signalNames = utils.getSinalNames(vessels);
		CommonQuery.getColumnName(vessels, (error, result) => {
			if (error) {
				next(error);
				return;
			}

			if (!result?.length) {
				return res.status(404).send({ signals: signalNames, message: ERROR_MSG.SIGNAL_NOT_FOUND })
			}
			let invalidSignals = [];
			let isSignalExists;
			if (result.length) {
				signalNames.forEach((x) => {
					isSignalExists = result.find((t) => t.nameAtSource === x);
					if (!isSignalExists) {
						invalidSignals.push(x);
					}
				});
			}
			message = ERROR_MSG.SIGNAL_NOT_FOUND
			if (invalidSignals.length) {
				if (invalidSignals.length > 1) {
					message = ERROR_MSG.SIGNALS_NOT_FOUND;
				}
				return res.status(404).send({ signals: invalidSignals, message: message })
			}

			FavoritesGetQuery.favget(payload, (error, result) => {
				if (error) {
					next(error);
					return;
				}
				vessels.map(x => {
					x.starttime = starttime;
					x.endtime = endtime;
				});
				let favObj = {}
				favObj.favorite_name = favorite_name;
				if (result.length > 0) {
					FavoriteUpdateQuery.favUpdate(vessels,favObj,user_id, (error, result) => {
						if (error) {
							next(error);
							return;
						}
						return res.status(200).send({ message: "Favorite updated successfully" });
					});
				}else{
					let favRecords = getFavResponse.getFavouriteRecords(vessels, user_id, favorite_name);
					FavoriteAddQuery.favadd(favRecords, (error, result) => {
						if (error) {
							next(error);
							return;
						}
						return res.status(200).send({ message: "Favorite added successfully" });
					});
				}
			});
			
		})
	});
};

// @desc      get favorites for vessels
// @route     POST /api/v2.1/favorites
// @access    Private
exports.getFavourites = (req, res, next) => {
	let favId = req.params.id?req.params.id:null;
	let userId = req.headers.user_id;
	let payload = {};
	payload.user_id = userId;
	payload.favorite_name = favId;

	//@des request data validator
	const errorResponse = validator.getRequestDataValidator(req);
	if (errorResponse?.statusCode !== 200) {
		return next(errorResponse);
	}

	// @desc      get all favorites or get by specific favoute by passing favorite as a query param
	FavoritesGetQuery.favget(payload, (error, result) => {
		if (error) {
			next(error);
			return;
		}
		// @desc get specific favorite response if record not foundx`
		if (!result?.length && favId) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 200));
		}
		// @desc get all response if not found records
		if (!result?.length) {
			return res.status(200).send(result);
		}
		result.map(x => {
			x.vessels = JSON.parse(x.vessels);
		});
		let vessels_list = [];
		for (let i = 0; i < result.length; i++) {
			let vessels = result[i].vessels;
			for (let j = 0; j < vessels.length; j++) {

				vessels_list.push(vessels[j]);
			}
		}
		let fav_list = result;
		let imo = utils.getIMOS(fav_list);
		let invalidImoList = [];
		// @desc validate IMO's valid or not
		CommonQuery.getOwnerId(imo, (error, result) => {

			if (!result?.length) {
				let invalidImos = utils.getInvalidImosList(fav_list);
				return res.status(404).send(invalidImos);
			}

			if (result.length) {
				imo.forEach((x) => {
					let isExist = result.find((t) => parseInt(t.imo) === x);
					if (!isExist) {
						invalidImoList.push(x);
					}
				});
			}

			// @desc it will get vessels metadata information
			SignalQuery.getSignals(vessels_list, (error, result) => {
				console.log("signal result:", vessels_list);
				if (error) {
					return next(error);
				}

				if (!result?.length) {
					const invalidVessels = utils.getInvalidImoOrSignal(fav_list, invalidImoList);
					return res.status(200).send(invalidVessels);
				}
				let signalMetadataResult;
				if (favId) {
					signalMetadataResult = getFavResponse.getSignalsMetadata(result, fav_list);
				} else {
					signalMetadataResult = utils.getFavoriteList(fav_list);
				}
				return res.status(200).send(signalMetadataResult);
			});
		})

	});
};

// @desc      delete favorite
// @route     POST /api/v2.1/favorite
// @access    Private
exports.deleteFavourite = (req, res, next) => {
	console.log("deleteFavorite controller", req.body);
	const favData = req.body;

	//@des request data validator
	const errorResponse = validator.deleteRequestDataValidator(req);
	if (errorResponse?.statusCode !== 200) {
		return next(errorResponse);
	}

	// @desc   deleting favorite which is not required
	FavoriteDeleteQuery.favDelete(favData, (error, result) => {
		if (error) {
			next(error);
			return;
		}
		return res.status(200).send({ message: "Favorite deleted successfully" });
	});
};
