/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const OwnerQuery = require("../database/queries/owner.query");
const FleetOwnerModel = require("../models/owner.model");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");

// @desc      Get all owner or get owners by owner_id
// @route     POST /api/v2.1/owners
// @access    Private
exports.postOwners = (req, res, next) => {
	const { owner_id } = req.body;

	if (!owner_id) {
		return next(new ErrorResponse("owner_id field is required!", 400));
	}

	if (!owner_id.length) {
		return next(
			new ErrorResponse("owner id can not be empty, please provide at least one owner id !", 400)
		);
	}

	OwnerQuery.postOwners(owner_id, (error, result) => {
		if (error) {
			return next(error);
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		const fleetOwners = [];
		for (const record of result) {
			const foundRecords = result.filter((x) => x.id === record.id);
			const fo = new FleetOwnerModel();
			if (foundRecords.length) {
				fo.id = foundRecords[0].id;
				fo.owner = foundRecords[0].owner_name;
				fo.country = foundRecords[0].country;
				fo.email = foundRecords[0].email;
				fo.imo = [];
			}
			for (const fr of foundRecords) {
				fo.imo.push(parseInt(fr.imo));
			}
			fleetOwners.push(fo);
		}

		const uniqueFleetOwner = [...new Map(fleetOwners.map((v) => [v.id, v])).values()];

		return res.status(200).send(uniqueFleetOwner.sort((a, b) => {
			if (a.owner > b.owner) { return -1; }
			if (a.owner < b.owner) { return 1; }
			return 0;
		}));
	});
};
