/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const CognitoService = require("../services/cognito.service");

exports.postSignupUser = async (req, res, next) => {
	const base64Credentials = (req.headers.authorization || "").split(" ")[1] || "";
	const [username, password] = Buffer.from(base64Credentials, "base64").toString().split(":");

	if (username && password) {
		const cognito = new CognitoService();
		try {
			cognito.signUp(username, password, (error, result) => {
				if (error) {
					next(error);
					return;
				}
				res.status(200).send(result);
			});
		} catch (e) {
			next(e);
			return;
		}
	}
};

exports.getUser = async (req, res, next) => {
	const accessToken = req.headers.authorization;
	const cognito = new CognitoService();
	try {
		cognito.getUser(accessToken, (error, result) => {
			if (error) {
				next(error);
				return;
			}
			res.status(200).send(result);
		});
	} catch (error) {
		next(error);
		return;
	}
};
