/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
// @desc      Get Fault List for signal(s)
// @route     POST /api/v2.1/faultlist
// @access    Private

exports.postFaultlist = (req, res, next) => {
    const fault_list = [{
        Owner: "CCT group",
        ShipName: "Sinnary",
        IMO: "9854621",
        DBNO: 14561,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "CCT group",
        ShipName: "MONTHMARE",
        IMO: "9854622",
        DBNO: 14562,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "CCT group",
        ShipName: "Lovre",
        IMO: "9854623",
        DBNO: 14563,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "CCT group",
        ShipName: "ship1",
        IMO: "9854624",
        DBNO: 14564,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup1",
        ShipName: "ship2",
        IMO: "9854625",
        DBNO: 14565,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup2",
        ShipName: "ship3",
        IMO: "9854626",
        DBNO: 14566,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup2",
        ShipName: "ship4",
        IMO: "9854627",
        DBNO: 14567,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup3",
        ShipName: "ship5",
        IMO: "9854628",
        DBNO: 14568,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup4",
        ShipName: "ship6",
        IMO: "9854629",
        DBNO: 14569,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup5",
        ShipName: "ship7",
        IMO: "9854630",
        DBNO: 14570,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup6",
        ShipName: "ship8",
        IMO: "9854631",
        DBNO: 14571,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup7",
        ShipName: "ship9",
        IMO: "9854632",
        DBNO: 14572,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup8",
        ShipName: "ship10",
        IMO: "9854633",
        DBNO: 14573,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup9",
        ShipName: "ship11",
        IMO: "9854634",
        DBNO: 14574,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup10",
        ShipName: "ship11",
        IMO: "9854635",
        DBNO: 14575,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup11",
        ShipName: "ship12",
        IMO: "9854636",
        DBNO: 14575,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup12",
        ShipName: "ship13",
        IMO: "9854637",
        DBNO: 14577,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup13",
        ShipName: "ship14",
        IMO: "9854638",
        DBNO: 14578,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup13",
        ShipName: "ship15",
        IMO: "9854639",
        DBNO: 14579,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup13",
        ShipName: "ship16",
        IMO: "9854640",
        DBNO: 14580,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup13",
        ShipName: "ship17",
        IMO: "9854641",
        DBNO: 14581,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup14",
        ShipName: "ship18",
        IMO: "9854642",
        DBNO: 14582,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup14",
        ShipName: "ship19",
        IMO: "9854643",
        DBNO: 14583,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup14",
        ShipName: "ship20",
        IMO: "9854644",
        DBNO: 14584,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup14",
        ShipName: "ship21",
        IMO: "9854645",
        DBNO: 14585,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup14",
        ShipName: "ship22",
        IMO: "9854646",
        DBNO: 14586,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship23",
        IMO: "9854647",
        DBNO: 14587,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship24",
        IMO: "9854648",
        DBNO: 14588,
        ActiveIssue: "Servo Oil Leakage",
        LatestIssue: "Piston Rings",
        FrequentIssue: "Compression Issue",
        SecondFrequentIssue:"Compression Issue"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship25",
        IMO: "9854649",
        DBNO: 14589,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship26",
        IMO: "9854650",
        DBNO: 14590,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship27",
        IMO: "9854651",
        DBNO: 14591,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship28",
        IMO: "9854652",
        DBNO: 14592,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup15",
        ShipName: "ship29",
        IMO: "9854653",
        DBNO: 14593,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup16",
        ShipName: "ship30",
        IMO: "9854654",
        DBNO: 14594,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup16",
        ShipName: "ship31",
        IMO: "9854655",
        DBNO: 14595,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup16",
        ShipName: "ship32",
        IMO: "9854656",
        DBNO: 14596,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup16",
        ShipName: "ship33",
        IMO: "9854658",
        DBNO: 14598,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup16",
        ShipName: "ship34",
        IMO: "9854659",
        DBNO: 14599,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    {
        Owner: "Ownergroup17",
        ShipName: "ship35",
        IMO: "9854660",
        DBNO: 14501,
        ActiveIssue: "Compression Issue",
        LatestIssue: "Servo Oil Leakage",
        FrequentIssue: "Piston Rings",
        SecondFrequentIssue:"Servo Oil Rail"
    },
    
]
    res.status(200).send(fault_list);
}