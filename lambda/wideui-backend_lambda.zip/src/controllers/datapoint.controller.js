/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const DatapointQuery = require("../database/queries/datapoint.query");

const CommonQuery = require("../database/queries/common.query");
const GetIndexesQuery = require("../database/queries/index.query");

const requestDataValidator = require("../validators/common-validator");
const ErrorResponse = require("../core/utility/error-response");
const addOwnerIdToPayload = require("../core/utility/add-owner-id-to-payload");
const ERROR_MSG = require("../core/constants/error-message");
const datapointRequestModelBuilder = require("../core/model-builder/request/datapoint-request-model-builder");
const datapointResponseModelBuilder = require("../core/model-builder/response/datapoint-response-model-builder");
const DATAPOINT_CONSTANTS = require("../core/constants/datapoint.constants");
const utils = require("../core/utility/datapoint.utility");
// @desc      Get datapoints for signal(s)
// @route     POST /api/v2.1/datapoints
// @access    Private
exports.postDatapoints = (req, res, next) => {
	console.log("postDatapoints controller", req.body);

	let { starttime, endtime, vessels, resolution, requestFrom } = req.body;

	// @desc      request body parameters validators
	const errorResponse = requestDataValidator(req, next);

	if (errorResponse?.statusCode !== 200) {
		return next(errorResponse);
	}

	starttime = new Date(starttime).toISOString();
	endtime = new Date(endtime).toISOString();
	const imo = vessels.map((x) => x.imo);

	// @desc      first get owner_id for each IMO
	CommonQuery.getOwnerId(imo, (error, result) => {
		console.log("owner result", result);

		if (error) {
			next(error);
			return;
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		if (result.length) {
			addOwnerIdToPayload(vessels, result);
		}

		// @desc      We yet don't have col_name information in payload
		//            so first we need to get col_name for each signal and prepare a payload
		CommonQuery.getColumnName(vessels, (error, result) => {
			if (error) {
				next(error);
				return;
			}

			if (!result?.length) {
				return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
			}
			const dpr = datapointRequestModelBuilder(starttime, endtime, vessels, result);
			dpr.resolution = resolution;

			if (resolution === DATAPOINT_CONSTANTS.RAW) {
				DatapointQuery.datapoints(dpr, (error, result) => {
					if (error) {
						next(error);
						return;
					}

					if (!result?.length) {
						return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
					}
					let signalDatapoints = datapointResponseModelBuilder(result, vessels);
					return res.status(200).send(signalDatapoints);
				});
			}

			// @desc      required start index and end index values to check difference row count
			// applying down sampling techniques if row difference count >5000
			GetIndexesQuery.getIndexes(dpr, (error, result) => {
				let indexDiffVal = utils.getMaxIndexValue(result);

				let datapoint_count_limit;
				if (requestFrom) {
					datapoint_count_limit = DATAPOINT_CONSTANTS.DASHBOARD_LIMIT;
				} else {
					datapoint_count_limit = DATAPOINT_CONSTANTS.LIMIT;
				}
				const resolutionRate = Math.round(indexDiffVal / datapoint_count_limit);
				dpr.indexDiffVal = indexDiffVal;
				if (indexDiffVal < datapoint_count_limit) {
					dpr.resolution = DATAPOINT_CONSTANTS.RAW;
				}else{
					dpr.resolutionRate = resolutionRate;
				}
				DatapointQuery.datapoints(dpr, (error, result) => {
					if (error) {
						next(error);
						return;
					}

					if (!result?.length) {
						return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
					}
					let signalDatapoints = datapointResponseModelBuilder(result, vessels);
					return res.status(200).send(signalDatapoints);
				});
			})
		});
	});
};
