/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const groupBy = require("../core/utility/groupby");
const signalRequestValidator = require("../validators/signal-request-validator");
const CommonQuery = require("../database/queries/common.query");
const SignalQuery = require("../database/queries/signal.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const signalResponseModelBuilder = require("../core/model-builder/response/signal-response-model-builder");

// @desc      Get all signals of a vessel or get signals of multiple vessels
// @route     POST /api/v2.1/signals
// @access    Private
exports.postSignals = (req, res, next) => {
	console.log("postSignals controller", req.body);

	const errorResponse = signalRequestValidator(req);

	if (errorResponse?.statusCode !== 200) {
		return next(errorResponse);
	}

	const signalsPayload = req.body;

	const imo = signalsPayload.map((x) => parseInt(x.imo));

	// @desc      From payload, we only get IMO(s), so first we need to get owner_id of each vessel
	//            and then form a payload to get signal list of each vessel/ship
	CommonQuery.getOwnerId(imo, (error, result) => {
		if (error) {
			return next(error);
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		const groupByOwnerId = groupBy(result, "owner_id");
		const payload = [];

		for (const [key, value] of Object.entries(groupByOwnerId)) {
			for (const row of value) {
				const sn = signalsPayload.find((x) => x.imo === parseInt(row.imo));
				payload.push({
					owner_id: row.owner_id,
					imo: parseInt(row.imo),
					signals: sn?.signals ? sn.signals : []
				});
			}
		}

		// @desc    get actual signal list of each vessel
		SignalQuery.getSignals(payload, (error, result) => {
			if (error) {
				return next(error);
			}

			if (!result?.length) {
				return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
			}

			return res.status(200).send(signalResponseModelBuilder(result, payload));
		});
	});
};
