/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const VesselQuery = require("../database/queries/vessel.query");
const FleetQuery = require("../database/queries/vessel.query");

const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const vesselRequestModelBuilder = require("../core/model-builder/request/vessel-request-model-builder");
const vesselResponseModelBuilder = require("../core/model-builder/response/vessel-response-model-builder");
// @desc      Get all ships/vessels or get ships/vessels by IMO
// @route     POST /api/v2.1/vessels
// @access    Private
exports.postVesselsByIMO = (req, res, next) => {
	const { imo } = req.body;

	if (!imo) {
		return next(new ErrorResponse("imo field is required !", 400));
	}

	if (!imo.length) {
		return next(new ErrorResponse("imo can not be empty, please provide at least one imo !", 400));
	}

	FleetQuery.postVesselsByIMO(imo, (error, result) => {
		if (error) {
			return next(error);
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		const intermidateVesselList = vesselRequestModelBuilder(result);

		// @desc      Get Vessels/ship's load params eg. “Nom_power_cmcr”: 12200, “Nom_revolution”: 95
		VesselQuery.getVesselLoadParams(intermidateVesselList, (error, result) => {
			if (error) {
				return next(error);
			}

			if (!result?.length) {
				return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
			}

			return res.status(200).send(vesselResponseModelBuilder(intermidateVesselList, result));
		});
	});
};
