/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const CommonQuery = require("../database/queries/common.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const SignalQuery = require("../database/queries/signal.query");
const addOwnerIdToPayload = require("../core/utility/add-owner-id-to-payload");
const requestDataValidator = require("../validators/common-validator");
const signalResponseModelBuilder = require("../core/model-builder/response/signal-response-model-builder");
const signalMetadataResponseBuilder = require("../core/model-builder/response/signal-metadata-response-model-builder");
const utils = require("../core/utility/common.utils");
const fs = require("fs");
const os = require("os");
const path = require("path");

// @desc      Get download signals data as .json
// @route     POST /api/v2.1/share
// @access    Private
exports.downloadJsonData = (req, res, next) => {
	console.log("downloadJsonData controller", req.body);

	let { starttime, endtime, vessels } = req.body;

	// @desc      request body parameters validators
	const errorResponse = requestDataValidator(req, next);

	if (errorResponse.statusCode !== 200) {
		return next(errorResponse);
	}

	starttime = new Date(starttime).toISOString();
	endtime = new Date(endtime).toISOString();
	const imo = vessels.map((x) => x.imo);

	// @desc      first get owner_id for each IMO
	CommonQuery.getOwnerId(imo, (error, result) => {
		console.log("owner result", result);

		if (error) {
			next(error);
			return;
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		if (result.length) {
			addOwnerIdToPayload(vessels, result);
		}

		// @desc      We yet don't have col_name information in payload
		//            so first we need to get col_name for each signal and prepare a payload
		CommonQuery.getColumnName(vessels, (error, result) => {
			if (error) {
				next(error);
				return;
			}

			if (!result?.length) {
				return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
			}

			// @desc it will get vessels metadata information
			SignalQuery.getSignals(vessels, (error, result) => {
				if (error) {
					return next(error);
				}

				if (!result?.length) {
					return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 200));
				}

				const signalMetadataResult = signalResponseModelBuilder(result, vessels);
				const finalSignalMetadataResult = signalMetadataResponseBuilder(signalMetadataResult, req);


				// @desc Create and download the json file
				// @desc upload file to temp folder
				let outputDir = "tempDir";
				let tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), outputDir));

				const jsonContent = JSON.stringify(finalSignalMetadataResult);
				//converting json data to json file
				const timedate = utils.getDateTime();
				let downloadName = `WiDE-ChartDataExport-${timedate}.json`;
				try {
					fs.writeFileSync(tmpDir + "/" + downloadName, jsonContent, { flag: "a+" });
					console.log("File written successfully");
				} catch (err) {
					console.error(err);
					return res.status(500).send("Got an failed while writing data to json file");
				}
				//download json file
				downloadJsonFile(tmpDir, downloadName, res);
			});
		});
	});
};

function downloadJsonFile(tmpDir, downloadName, res) {
	try {
		let filePath = tmpDir + "/" + downloadName;

		// code to download zip file
		res.set("Content-Type", "application/octet-stream");
		res.set("Content-Disposition", `attachment; filename=${downloadName}`);
		res.download(filePath, (err) => {
			console.log("file path:", filePath);
			if (err) {
				console.log("error in file download:", err);
				return res.send("Got an failed while downloading file");
			}
			if (fs.existsSync(filePath)) {
				utils.deleteTempDir(tmpDir);
			}
			console.log("file downloaded successfully");
		});
	} catch (err) {
		console.log(err);
		return res.status(500).send({ message: "Got an failed while downloading file" });
	}
}
