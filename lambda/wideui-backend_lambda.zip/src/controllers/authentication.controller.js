/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const CognitoService = require("../services/cognito.service");

exports.postLogin = async (req, res, next) => {
	const base64Credentials = (req.headers.authorization || "").split(" ")[1] || "";
	const [username, password] = Buffer.from(base64Credentials, "base64").toString().split(":");
	if (username && password) {
		try {
			const cognito = new CognitoService();
			let authenticationResult = {};
			cognito.signInUser(username, password, (error, cognitoResult) => {
				if (error) {
					next(error);
					return;
				}
				cognito.getUser(cognitoResult?.AuthenticationResult?.AccessToken, (error, userResult) => {
					if (error) {
						next(error);
						return;
					}

					authenticationResult = {
						cognito: cognitoResult,
						user: userResult
					}

					return res.status(200).send(authenticationResult);
				})
			});
		} catch (error) {
			next(error);
			return;
		}
	} else {
		return res.status(400).send("Invalid request !");
	}
};
