/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const DatapointQuery = require("../database/queries/datapoint.query");
const CommonQuery = require("../database/queries/common.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");
const SignalQuery = require("../database/queries/signal.query");
const addOwnerIdToPayload = require("../core/utility/add-owner-id-to-payload");
const datapointRequestModelBuilder = require("../core/model-builder/request/datapoint-request-model-builder");
const datapointResponseModelBuilder = require("../core/model-builder/response/datapoint-response-model-builder");
const requestDataValidator = require("../validators/common-validator");
const signalResponseModelBuilder = require("../core/model-builder/response/signal-response-model-builder");
const signalMetadataResponseBuilder = require("../core/model-builder/response/signal-metadata-response-model-builder");
const utils = require("../core/utility/common.utils");
const GetIndexesQuery = require("../database/queries/index.query");
const DATAPOINT_CONSTANTS = require("../core/constants/datapoint.constants");
const fs = require("fs");
const os = require("os");
const path = require("path");
const json2csv = require("json2csv").parse;
const FILE_NAME = require("../core/constants/file-name.constant");

// @desc      Get download signals data as a zip file, it contains .csv, .json
// @route     POST /api/v2.1/download
// @access    Private
exports.postDownloadData = (req, res, next) => {
	console.log("postDownloadData controller", req.body);

	let { starttime, endtime, vessels, resolution } = req.body;

	// @desc      request body parameters validators
	const errorResponse = requestDataValidator(req, next);

	if (errorResponse.statusCode !== 200) {
		return next(errorResponse);
	}

	starttime = new Date(starttime).toISOString();
	endtime = new Date(endtime).toISOString();
	const imo = vessels.map((x) => x.imo);

	// @desc      first get owner_id for each IMO
	CommonQuery.getOwnerId(imo, (error, result) => {
		console.log("owner result", result);

		if (error) {
			next(error);
			return;
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		if (result.length) {
			addOwnerIdToPayload(vessels, result);
		}

		// @desc      We yet don't have col_name information in payload
		//            so first we need to get col_name for each signal and prepare a payload
		CommonQuery.getColumnName(vessels, (error, result) => {
			if (error) {
				next(error);
				return;
			}

			if (!result?.length) {
				return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
			}

			const dpr = datapointRequestModelBuilder(starttime, endtime, vessels, result);

			// @desc it will get vessels metadata information
			SignalQuery.getSignals(vessels, (error, result) => {
				if (error) {
					return next(error);
				}

				if (!result?.length) {
					return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
				}

				const signalMetadataResult = signalResponseModelBuilder(result, vessels);
				const finalSignalMetadataResult = signalMetadataResponseBuilder(signalMetadataResult, req);

				// @desc      after preparing the appropriate payload, get datapoints for each signal
				dpr.isDownloadAPI = true;
				dpr.resolution = resolution;
				// @desc      required start index and end index values to check difference row count
				// applying down sampling techniques if row difference count >5000
				GetIndexesQuery.getIndexes(dpr, (error, result) => {
					
					if (!result?.length) {
						return res.status(200).send(result);
					}

					let startIndex = ((result[0])[0]).id;
					let endIndex = ((result[0])[1]).id;
					const indexDiffVal = endIndex - startIndex;
					const resolutionRate = Math.round(indexDiffVal / DATAPOINT_CONSTANTS.LIMIT);
					console.log("indexDiffVal", indexDiffVal);
					console.log("resolutionRate", resolutionRate);
					dpr.indexDiffVal = indexDiffVal;
					dpr.resolutionRate = resolutionRate;
					if (indexDiffVal < DATAPOINT_CONSTANTS.LIMIT) {
						dpr.resolution = DATAPOINT_CONSTANTS.RAW;
					}
					DatapointQuery.datapoints(dpr, (error, result) => {
						if (error) {
							next(error);
							return;
						}
						if (!result?.length) {
							return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
						}
						vessels.isDownloadAPI = true;
						const datapointMetadataResult = datapointResponseModelBuilder(result, vessels);
						// @desc Create and download the zip file
						// @desc upload file to temp folder
						let outputDir = "tempDir";
						let tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), outputDir));

						const jsonContent = JSON.stringify(finalSignalMetadataResult);
						//converting json data to json file
						try {
							fs.writeFileSync(`${tmpDir}/${FILE_NAME.JSON}`, jsonContent, { flag: "a+" });
						} catch (err) {
							console.error(err);
							return res.status(500).send("Got an failed while writing data to json file");
						}
						let jsonData = utils.groupJsonData(datapointMetadataResult);
						//converting json data to csv file
						try {
							const csvData = json2csv(jsonData);
							fs.writeFileSync(`${tmpDir}/${FILE_NAME.CSV}`, csvData);
						} catch (err) {
							console.error(err);
							return res
								.status(500)
								.send({ message: "Got an failed while writing data to csv file" });
						}
						//zip the file and download it
						return res.status(200).send(utils.downloadFileBlob(tmpDir, [FILE_NAME.JSON, FILE_NAME.CSV]));
					});
				});
			});
		});
	});
};

