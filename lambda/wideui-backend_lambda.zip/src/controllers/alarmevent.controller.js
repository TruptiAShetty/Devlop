/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const AlarmeventQuery = require("../database/queries/alarmevent.query");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");

// @desc      Get alarm events
// @route     POST /api/v2.1/alarmevents
// @access    Private
exports.postAlarmevent = (req, res, next) => {
	const { starttime, endtime, imo } = req.body;

	if (!starttime) {
		return next(new ErrorResponse("starttime field is required", 400));
	}

	if (isNaN(starttime)) {
		return next(new ErrorResponse("starttime must be an EPOC timestamp", 400));
	}

	if (!endtime) {
		return next(new ErrorResponse("endtime field is required", 400));
	}

	if (isNaN(endtime)) {
		return next(new ErrorResponse("endtime must be an EPOC timestamp", 400));
	}

	if (!endtime) {
		return next(new ErrorResponse("endtime field is required", 400));
	}

	if (!imo) {
		return next(new ErrorResponse("imo is required", 400));
	}

	const payload = { starttime: starttime, endtime: endtime, imo: imo };

	AlarmeventQuery.getAlarmevents(payload, (error, result) => {
		if (error) {
			return next(error);
		}

		if (!result?.length) {
			return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
		}

		return res.status(200).send(result);
	});
};
