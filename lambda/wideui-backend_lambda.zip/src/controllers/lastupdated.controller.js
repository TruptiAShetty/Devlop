/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const addOwnerIdToPayload = require("../core/utility/add-owner-id-to-payload");
const LastUpdatedQuery = require("../database/queries/lastupdated.query");
const CommonQuery = require("../database/queries/common.query");
const datapointRequestModelBuilder = require("../core/model-builder/request/datapoint-request-model-builder");
const utils = require("../core/utility/lastupdated.utils");
const ErrorResponse = require("../core/utility/error-response");
const ERROR_MSG = require("../core/constants/error-message");

// @desc      last updated time for IMO/signals
// @route     POST /api/v2.1/lastupdated
// @access    Private
exports.lastUpdated = (req, res, next) => {
    console.log("lastUpdated controller", req.body);

    let vessels = req.body;

    const imo = vessels.map((x) => x.imo);

    // @desc      first get owner_id for each IMO
    CommonQuery.getOwnerId(imo, (error, result) => {
        console.log("owner result", result);

        if (error) {
            next(error);
            return;
        }

        if (!result?.length) {
            return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
        }

        if (result.length) {
            addOwnerIdToPayload(vessels, result);
        }
        let [signalsData, imoData] = utils.buildSignalsData(vessels);
        // it will execute when signal names present in request payload
        if (signalsData.length) {
            // @desc      We yet don't have col_name information in payload
            //            so first we need to get col_name for each signal and prepare a payload
            CommonQuery.getColumnName(signalsData, (error, result) => {
                if (error) {
                    next(error);
                    return;
                }

                if (!result?.length) {
                    return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
                }
                const dpr = datapointRequestModelBuilder("", "", vessels, result);
                utils.buildVesselsQueryRequestData(dpr, imoData);
                vessels = dpr.vessels;
                LastUpdatedQuery.getSignaldate(vessels, (error, result) => {
                    if (error) {
                        next(error);
                        return;
                    }

                    if (!result?.length) {
                        return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
                    }
                    return res.status(200).send(result);
                })
            })
        } else {
            LastUpdatedQuery.getSignaldate(vessels, (error, result) => {
                if (error) {
                    next(error);
                    return;
                }

                if (!result?.length) {
                    return next(new ErrorResponse(ERROR_MSG.NO_RECORDS_FOUND, 404));
                }
                return res.status(200).send(result);
            })
        }
    })
}
