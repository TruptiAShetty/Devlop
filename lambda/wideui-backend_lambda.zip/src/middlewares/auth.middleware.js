/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const jwt = require("jsonwebtoken");
const jwkToPem = require("jwk-to-pem");
const fetch = require("node-fetch");
const config = require("../core/config/config.json");
let pems = {};

class AuthMiddleWare {
	region = config.aws.region;
	userPoolId = config.cognito.userPoolId;

	constructor() {
		this.setUp();
	}

	verifyToken(req, res, next) {
		console.log("header", req.headers.authorization);
		const token = req.headers.authorization;
		console.log("token", token);

		if (!token) {
			res.status(401).end();
			return;
		}

		let decodeJWT = jwt.decode(token, { complete: true });
		console.log("decodeJWT", decodeJWT);
		if (!decodeJWT) {
			res.status(401).end();
			return;
		}

		let kid = decodeJWT.header.kid;
		let pem = pems[kid];

		if (!pem) {
			res.send(401).end();
		}

		jwt.verify(token, pem, (err, result, next) => {
			if (err) {
				console.log("error occured");
				res.status(401).end();
			}
			console.log("jwt.verify", result);
			next();
		});
	}

	async setUp() {
		const URL = config.cognito.jwkURL;

		try {
			const response = await fetch(URL);

			if (response.status !== 200) {
				throw "request was not successful";
			}

			const data = await response.json();
			const { keys } = data;

			for (let index = 0; index < keys.length; index++) {
				const key = keys[index];
				const key_id = key.kid;
				const modulus = key.n;
				const exponent = key.e;
				const key_type = key.kty;
				const jwk = { kty: key_type, n: modulus, e: exponent };

				const pem = jwkToPem(jwk);

				pems[key_id] = pem;
			}

			console.log("get all pems");
		} catch (error) {
			console.log("sorry couldn't fetch JWT", error);
			next();
		}
	}
}

module.exports = AuthMiddleWare;
