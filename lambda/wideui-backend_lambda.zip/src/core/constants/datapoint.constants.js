/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const DATAPOINT_CONSTANTS = {
    LIMIT: 5000,
    DASHBOARD_LIMIT: 100,
    RAW: "raw",
    FIXED_1SECOND: 'fixed_1second',
    FIXED_1MIN: 'fixed_1min',
    FIXED_1HOUR: 'fixed_1hour',
    AUTOLOADING_SINGLESAMPLE: 'autoloading_singlesample',
    AUTOLOADING_AVG: 'autoloading_avg',
};

module.exports = DATAPOINT_CONSTANTS;