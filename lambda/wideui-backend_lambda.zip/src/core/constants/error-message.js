/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const ERROR_MSG = {
	NO_RECORDS_FOUND: "No records found !",
	SIGNAL_NOT_FOUND: "Signal not valid !",
	SIGNALS_NOT_FOUND: "Signals not valid !",
	IMO_NOT_FOUND: "IMO not valid !",
	IMOS_NOT_FOUND: "IMO records not found !",
	IMOS_OR_SIGNAL_NOT_FOUND: "IMO or signal not valid !"
};

module.exports = ERROR_MSG;
