/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
exports.buildSignalsData = (vessels) => {
    const signalsData = [];
    const imoData = [];
    for (let i = 0; i < vessels.length; i++) {
        if (vessels[i].signals) {
            signalsData.push(vessels[i]);
        } else {
            imoData.push(vessels[i]);
        }
    }
    return [signalsData, imoData];
}
exports.buildVesselsQueryRequestData = (dpr, imoData) => {
    imoData.forEach(x => {
        dpr.vessels.push(x);
    });
}