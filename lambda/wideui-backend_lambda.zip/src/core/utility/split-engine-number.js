/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const ENGIN_NUMBER_DIVIDER = require("../constants/engine-number-divider");

const SPLIT_ENGINE_NUNBER = (enginenumber) => {
	const splitEnginenumbers = [];
	if (enginenumber) {
		if (enginenumber.includes(ENGIN_NUMBER_DIVIDER)) {
			const dbNumberInArray = enginenumber.split(ENGIN_NUMBER_DIVIDER);
			for (const db of dbNumberInArray) {
				splitEnginenumbers.push(db.trim());
			}
		} else {
			splitEnginenumbers.push(enginenumber);
		}
	}

	return splitEnginenumbers;
};

module.exports = SPLIT_ENGINE_NUNBER;
