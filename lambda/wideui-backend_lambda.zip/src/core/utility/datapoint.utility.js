/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
exports.getMaxIndexValue = (result) => {
    let indexArr = [];
    result?.forEach(index => {
        if (index.length > 0) {
            let val = (index[1]).id - (index[0]).id
            indexArr.push(val);
        }
    });
    console.log("indexArr values:",indexArr);
    return Math.max(...indexArr);
}