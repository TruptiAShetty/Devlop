/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const fs = require("fs");
const ERROR_MSG = require("../../core/constants/error-message");

// @desc      return common responses
exports.getDateTime = () => {
	const currDate = new Date();
	let timedate = currDate.getFullYear().toString();
	timedate += (currDate.getMonth() + 1).toString();
	timedate += currDate.getDate().toString();
	timedate += currDate.getHours().toString();
	timedate += currDate.getMinutes().toString();
	timedate += currDate.getSeconds().toString();
	return timedate;
};

exports.deleteTempDir = (tempDir) => {
	if (fs.existsSync(tempDir)) {
		const uploadDir = fs.readdirSync(tempDir);
		for (let i in uploadDir) {
			fs.unlinkSync(tempDir + "/" + uploadDir[i]);
		}
	}
};

exports.downloadFileBlob = (tmpDir, filenames) => {
	try {
		const data = [];
		if (filenames.length) {
			for (let i = 0; i < filenames.length; i++) {
				data.push({ filename: filenames[i], blob: fs.readFileSync(`${tmpDir}/${filenames[i]}`) });
				this.deleteFile(`${tmpDir}/${filenames[i]}`);
			}
			this.deleteTempDir(tmpDir);
		}
		return data;
	} catch (err) {
		console.log(err);
	}
}

exports.deleteFile = (filePath) => {
	try {
		if (fs.existsSync(filePath)) {
			fs.unlinkSync(filePath);
		}
	} catch (err) {
		console.log(err);
	}
}

exports.groupJsonData = (jsonData) => {
	let groupData;
	for (let index in jsonData) {
		if (index == 0) {
			groupData = jsonData[index].datapoints;
		} else {
			let datapoints = jsonData[index].datapoints;
			let csv_signal_name = jsonData[index].csv_signal_name;
			let datetime = jsonData[index].datetime;
			for (let j = 0; j < datapoints.length; j++) {
				if(groupData[j]){
					groupData[j][csv_signal_name] = datapoints[j][csv_signal_name];
				}else{
					let obj = {};
					obj[csv_signal_name] = datapoints[j][csv_signal_name];
					obj.datetime = datapoints[j].datetime;
					groupData.push(obj);
				}
			}
		}
	}
	return groupData;
}

exports.getSinalNames = (vessels) => {
	let signalNames = [];
	vessels.map(vessel => {
		signals = vessel.signals;
		signals.map(x => {
			signalNames.push(x.signalname);
		})
	})
	return signalNames;
}
exports.getFavoriteList = (results) => {
	const favoriteList = [];
	results.map(x => {
		let Obj = {};
		Obj.favorite_name = x.favorite_name;
		Obj.user_id = x.user_id;
		favoriteList.push(Obj);
	})
	return favoriteList;
}
exports.getInvalidImoOrSignal = (results, invalidImoList) => {
	for (let i = 0; i < results.length; i++) {
		results[0].starttime = new Date(results[0].vessels[0].starttime).getTime();
		results[0].endtime = new Date(results[0].vessels[0].endtime).getTime();
		for (let j = 0; j < results[i].vessels.length; j++) {
			if (invalidImoList.includes(results[i].vessels[j].imo)) {
				results[i].vessels[j].message = ERROR_MSG.IMO_NOT_FOUND;
				delete results[i].vessels[j].starttime;
				delete results[i].vessels[j].endtime;
			}
			for (let k = 0; k < results[i].vessels[j].signals.length; k++) {
				results[i].vessels[j].signals[k].message = ERROR_MSG.SIGNAL_NOT_FOUND;
			}
		}
	}
	return results;
}
exports.getInvalidImosList = (results) => {
	for (let i = 0; i < results.length; i++) {
		results[0].starttime = new Date(results[0].vessels[0].starttime).getTime();
		results[0].endtime = new Date(results[0].vessels[0].endtime).getTime();
		for (let j = 0; j < results[i].vessels.length; j++) {
			results[i].vessels[j].message = ERROR_MSG.IMO_NOT_FOUND;
			delete results[i].vessels[j].starttime;
			delete results[i].vessels[j].endtime;
		}
	}
	return results;
}
exports.getIMOS = (fav_list) => {
	let IMOS = [];
	fav_list.map(x => {
		let vessels = x.vessels;
		vessels.map(y => {
			IMOS.push(y.imo);
		})
	})
	return IMOS
		;
}