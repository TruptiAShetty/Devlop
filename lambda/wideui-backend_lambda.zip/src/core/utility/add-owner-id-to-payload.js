/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const addOwnerIdToPayload = (vessels, result) => {
	vessels = vessels.map((x) => {
		x.owner_id = result.find((t) => parseInt(t.imo) === x.imo).owner_id;
		return x;
	});
};

module.exports = addOwnerIdToPayload;
