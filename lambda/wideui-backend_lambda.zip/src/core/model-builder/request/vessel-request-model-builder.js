/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const SPLIT_ENGINE_NUNBER = require("../../../core/utility/split-engine-number");
const VesselModel = require("../../../models/vessel.model");
const vesselRequestModelBuilder = (result) => {
	const intermidateVesselList = [];
	for (const record of result) {
		const vessel = new VesselModel();
		vessel.id = record.id;
		vessel.imo = parseInt(record.imo);
		vessel.ship_name = record.ship_name;
		vessel.type = record.type;
		vessel.ems1 = record.ems1;
		vessel.ems2 = record.ems2;
		vessel.engine_type = record.engine_type;
		vessel.owner_id = record.owner_id;
		vessel.enginenumber = SPLIT_ENGINE_NUNBER(record.dbnumber);
		intermidateVesselList.push(vessel);
	}

	return intermidateVesselList;
};

module.exports = vesselRequestModelBuilder;
