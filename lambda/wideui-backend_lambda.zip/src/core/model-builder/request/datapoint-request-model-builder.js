/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const DatapointRequestModel = require("../../../models/request/datapoint-request.model");
const DatapointVesselRequestModel = require("../../../models/request/datapoint-vessel-request.model");
const DatapointVesselSignalRequestModel = require("../../../models/request/datapoint-vessel-signal-request.model");
const groupBy = require("../../utility/groupby");

const datapointRequestModelBuilder = (starttime, endtime, vessels, getColumnNameResult) => {
	const dpr = new DatapointRequestModel();

	dpr.starttime = starttime;
	dpr.endtime = endtime;
	dpr.vessels = [];
	for (const vessel of vessels) {
		const dpvr = new DatapointVesselRequestModel();
		dpvr.imo = vessel.imo;
		dpvr.owner_id = vessel.owner_id;
		dpvr.signals = [];
		const signalDetailForGivenIMOList = getColumnNameResult.filter(
			(x) => x.imo === vessel.imo && x.owner_id == vessel.owner_id
		);
		if (signalDetailForGivenIMOList.length) {
			const groupByTableName = groupBy(signalDetailForGivenIMOList, "groupName");
			if (groupByTableName) {
				for (const [key, value] of Object.entries(groupByTableName)) {
					const dpvsr = new DatapointVesselSignalRequestModel();
					dpvsr.col_name = [];
					dpvsr.description = [];
					dpvsr.nameAtSource = [];
					dpvsr.rangeMax = [];
					dpvsr.rangeMin=[];
					dpvsr.groupName = key;
					for (const obj of value) {
						dpvsr.col_name.push(obj.col_name);
						dpvsr.description.push(obj.description);
						dpvsr.nameAtSource.push(obj.nameAtSource);
						dpvsr.rangeMax.push(obj.rangeMax);
						dpvsr.rangeMin.push(obj.rangeMin);
					}
					dpvr.signals.push(dpvsr);
				}
				dpr.vessels.push(dpvr);
			}
		}
	}

	return dpr;
};

module.exports = datapointRequestModelBuilder;
