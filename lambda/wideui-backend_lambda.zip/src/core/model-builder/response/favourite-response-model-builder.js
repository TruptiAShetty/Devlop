/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const SignalModel = require("../../../models/signal.model");
const SignalDetailModel = require("../../../models/signal-detail.model");
const SPLIT_ENGINE_NUNBER = require("../../../core/utility/split-engine-number");
const groupBy = require("../../utility/groupby");
const ERROR_MSG = require("../../../core/constants/error-message");

// @desc it will return favorite records which is going add in database
exports.getFavouriteRecords = (vessels,user_id,favorite_name) => {
	const favRecords = [];
	const data = [];
	const signals = JSON.stringify(vessels);
	data.push(user_id);
	data.push(favorite_name);
	data.push(signals);
	favRecords.push(data);
	return favRecords;
};

// @desc it will prepare signal metadata for each imo and send it back to UI

exports.getSignalsMetadata = (signalQueryResult, payload) => {
	const signalMetadataResult = [];
	const favoriteListModel = [];

	const groupbyIMO = groupBy(signalQueryResult, "imo");
	if (groupbyIMO) {
		for (const [key, records] of Object.entries(groupbyIMO)) {
			const signalModel = new SignalModel();
			signalModel.imo = parseInt(key);
			signalModel.signals = [];
			for (const record of records) {
				const signalDetailModel = new SignalDetailModel();
				signalModel.enginenumber = SPLIT_ENGINE_NUNBER(record.enginenumber);
				signalDetailModel.source = record.groupName;
				signalDetailModel.signalName = record.name;
				signalDetailModel.description = record.description;
				signalDetailModel.engUnit = record.unit;
				signalDetailModel.rangeMin = record.rangeMin;
				signalDetailModel.rangeMax = record.rangeMax;
				signalDetailModel.display_rangeMin = record.rangeMin;
				signalDetailModel.display_rangeMax = record.rangeMax;

				signalModel.signals.push(signalDetailModel);
			}

			signalMetadataResult.push(signalModel);
		}
	}
	for(let i = 0; i<payload.length; i++){
		let vessels = payload[i].vessels;
		let favoriteModel = {};
		favoriteModel.favorite_name = payload[i].favorite_name;
		favoriteModel.user_id = payload[i].user_id;
		favoriteModel.vessels = [];
		const SignalDataModel = [];
		for (const record of vessels) {
			const signalModel = new SignalModel();
			signalModel.imo = record.imo;
			favoriteModel.starttime = new Date(record.starttime).getTime();
			favoriteModel.endtime = new Date(record.endtime).getTime();
			signalModel.signals = [];
			const foundIMO = signalMetadataResult.find(x => x.imo === record.imo);
			if (foundIMO) {
				signalModel.imo = foundIMO.imo;
				signalModel.enginenumber = foundIMO.enginenumber;
				if (record?.signals?.length) {
					for (const s of record.signals) {
						const foundSignal = foundIMO?.signals.find(x => x.signalName === s.signalname && x.source === s.source);
						if (foundSignal) {
							foundSignal.color = s.color;
							foundSignal.display_rangeMax = s.display_rangemax;
							foundSignal.display_rangeMin = s.display_rangemin;
							signalModel.signals.push(foundSignal);
						} else {
							const signalDetailModel = new SignalDetailModel();
							signalDetailModel.signalName = s.signalname;
							signalDetailModel.source = s.source;
							signalDetailModel.color = s.color;
							signalDetailModel.display_rangeMax = s.display_rangemax;
							signalDetailModel.display_rangeMin = s.display_rangemin;
							signalDetailModel.message = ERROR_MSG.SIGNAL_NOT_FOUND;
							signalModel.signals.push(signalDetailModel);
						}
					}
				} else {
					signalModel.signals = foundIMO.signals;
				}
			} else {
				signalModel.signals = record.signals;
				signalModel.message = ERROR_MSG.IMO_NOT_FOUND;
			}
			SignalDataModel.push(signalModel);
		}
		favoriteModel.vessels = SignalDataModel;
		favoriteListModel.push(favoriteModel);

	}
	return favoriteListModel;
};
