/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const SignalModel = require("../../../models/signal.model");
const SignalDetailModel = require("../../../models/signal-detail.model");
const SPLIT_ENGINE_NUNBER = require("../../../core/utility/split-engine-number");
const groupBy = require("../../utility/groupby");
const ERROR_MSG = require("../../../core/constants/error-message");

const signalResponseModelBuilder = (signalQueryResult, payload) => {
	const SignalDataModel = [];
	const signalMetadataResult = [];

	const groupbyIMO = groupBy(signalQueryResult, "imo");
	if (groupbyIMO) {
		for (const [key, records] of Object.entries(groupbyIMO)) {
			const signalModel = new SignalModel();
			signalModel.imo = parseInt(key);
			signalModel.signals = [];
			for (const record of records) {
				const signalDetailModel = new SignalDetailModel();
				signalModel.enginenumber = SPLIT_ENGINE_NUNBER(record.enginenumber);
				signalDetailModel.source = record.groupName;
				signalDetailModel.signalName = record.name;
				signalDetailModel.description = record.description;
				signalDetailModel.engUnit = record.unit;
				signalDetailModel.rangeMin = record.rangeMin;
				signalDetailModel.rangeMax = record.rangeMax;
				signalDetailModel.display_rangeMin = record.rangeMin;
				signalDetailModel.display_rangeMax = record.rangeMax;

				signalModel.signals.push(signalDetailModel);
			}

			signalMetadataResult.push(signalModel);
		}
	}

	for (const record of payload) {
		const signalModel = new SignalModel();
		signalModel.imo = record.imo;
		signalModel.signals = [];
		const foundIMO = signalMetadataResult.find((x) => x.imo === record.imo);
		if (foundIMO) {
			signalModel.imo = foundIMO.imo;
			signalModel.enginenumber = foundIMO.enginenumber;
			if (record?.signals?.length) {
				for (const s of record.signals) {
					const foundSignal = foundIMO?.signals.find(
						(x) => x.signalName === s.signalname && x.source === s.source
					);
					if (foundSignal) {
						signalModel.signals.push(foundSignal);
					} else {
						const signalDetailModel = new SignalDetailModel();
						signalDetailModel.signalName = s.signalname;
						signalDetailModel.source = s.source;
						signalDetailModel.message = ERROR_MSG.NO_RECORDS_FOUND;
						signalModel.signals.push(signalDetailModel);
					}
				}
			} else {
				signalModel.signals = foundIMO.signals;
			}
		} else {
			signalModel.message = ERROR_MSG.NO_RECORDS_FOUND;
		}

		SignalDataModel.push(signalModel);
	}

	return SignalDataModel;
};

module.exports = signalResponseModelBuilder;
