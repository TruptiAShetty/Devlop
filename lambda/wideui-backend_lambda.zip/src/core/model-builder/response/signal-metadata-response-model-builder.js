/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

const signalMetadataResponseBuilder = (signalQueryResult, req) => {
    let { starttime, endtime } = req.body;
    const SignalDataModel = [];
    let vesselsModel = {};
    vesselsModel.starttime = starttime;
    vesselsModel.endtime = endtime;
    vesselsModel.vessels = [];
    signalQueryResult.map(x => {
        vesselsModel.vessels.push(x);
    })
    SignalDataModel.push(vesselsModel);

    return SignalDataModel;
};

module.exports = signalMetadataResponseBuilder;
