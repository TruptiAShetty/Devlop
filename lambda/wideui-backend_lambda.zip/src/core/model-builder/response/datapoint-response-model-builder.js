/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const DatapointModel = require("../../../models/datapoint.model");
const ERROR_MSG = require("../../../core/constants/error-message");

const datapointResponseModelBuilder = (datapointQueryResult, payload) => {
	const datapointDataModel = [];
	const datapointMetadataResult = [];

	for (const queryResult of datapointQueryResult) {
		for (const result of queryResult) {
			if (result !== null) {
				const datapointModel = new DatapointModel();
				datapointModel.imo = result.imo;
				datapointModel.signalName = result.signalName;
				datapointModel.source = result.source;
				datapointModel.datapoints = result.datapoints;
				if (payload.isDownloadAPI) {
					console.log("setting csv_signal_name");
					console.log("csv_signal_name:",result.csv_signal_name);
					datapointModel.csv_signal_name = result.csv_signal_name;
				}
				datapointMetadataResult.push(datapointModel);
			}
		}
	}

	for (const record of payload) {
		const datapointModel = new DatapointModel();
		for (const s of record.signals) {
			const foundSignalWithDatapoints = datapointMetadataResult.find(
				(x) => x.imo === record.imo && x.signalName === s.signalname && x.source === s.source
			);
			if (foundSignalWithDatapoints) {
				datapointDataModel.push(foundSignalWithDatapoints);
			} else {
				datapointModel.imo = record.imo;
				datapointModel.signalName = s.signalname;
				datapointModel.source = s.source;
				datapointModel.datapoints = [];
				datapointModel.message = ERROR_MSG.NO_RECORDS_FOUND;
				if (payload.isDownloadAPI) {
					datapointModel.csv_singal_name = record.imo + "." + s.source + "." + s.signalname;
				}
				datapointDataModel.push(datapointModel);
			}
		}
	}

	return datapointDataModel;
};

module.exports = datapointResponseModelBuilder;
