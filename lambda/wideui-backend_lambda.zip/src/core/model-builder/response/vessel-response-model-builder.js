/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const VesselModel = require("../../../models/vessel.model");
const vesselResponseModelBuilder = (intermidateVesselList, vesselLoadParamResult) => {
	const finalVesselResult = [];
	for (const record of intermidateVesselList) {
		const vessel = new VesselModel();
		vessel.id = record.id;
		vessel.imo = record.imo;
		vessel.ship_name = record.ship_name;
		vessel.type = record.type;
		vessel.ems1 = record.ems1;
		vessel.ems2 = record.ems2;
		vessel.engine_type = record.engine_type;
		vessel.enginenumber = record.enginenumber;

		const findLoadParam = vesselLoadParamResult.find((x) => x.imo === vessel.imo);
		if (findLoadParam) {
			vessel.nom_power_cmcr = findLoadParam.nom_power_cmcr;
			vessel.mom_revolution = findLoadParam.mom_revolution;
		}

		finalVesselResult.push(vessel);
	}

	return finalVesselResult;
};
module.exports = vesselResponseModelBuilder;
