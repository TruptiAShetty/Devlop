/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

exports.downloadApiRequestBody = () => {
    const payload = {
        "starttime": 1518796837000,
        "endtime": 1518797118000,
        "vessels": [
            {
                "imo": 8999748,
                "signals": [
                    {
                        "signalname": "TE3701A",
                        "source": "ems_1_signals"
                    }
                ]
            },
            {
                "imo": 8269772,
                "signals": [
                    {
                        "signalname": "signaldate",
                        "source": "signals"
                    }
                ]
            }
        ]
    }
    return payload;
}

exports.downloadApiRequestBody = () => {
    const payload = {
        "starttime": 1518796837000,
        "endtime": 1518797118000,
        "vessels": [
            {
                "imo": 8999748,
                "owner_id": 10,
                "signals": [
                    {
                        "signalname": "TE3701A",
                        "source": "ems_1_signals"
                    }
                ]
            },
            {
                "imo": 8269772,
                "owner_id": 10,
                "signals": [
                    {
                        "signalname": "signaldate",
                        "source": "signals"
                    }
                ]
            }
        ]
    }
    return payload;
}

exports.favoriteApiReqData = () => {
    const payload = {
        "starttime": 1518796837000,
        "endtime": 1518797118000,
        "favorite_name": "Fav_A",
        "vessels": [
            {
                "imo": 8999748,
                "owner_id": 10,
                "signals": [
                    {
                        "signalname": "TE3701A",
                        "source": "ems_1_signals"
                    }
                ]
            },
            {
                "imo": 8269772,
                "owner_id": 10,
                "signals": [
                    {
                        "signalname": "signaldate",
                        "source": "signals"
                    }
                ]
            }
        ]
    }
    return payload;
}
exports.renameApiReqData = () => {
    const payload = {
        "starttime": 1518796837000,
        "endtime": 1518797118000,
        "favorite_name": "Fav_A",
        "old_favorite_name": "Fav_B",
        "vessels": [
            {
                "imo": 8999748,
                "owner_id": 10,
                "signals": [
                    {
                        "signalname": "TE3701A",
                        "source": "ems_1_signals"
                    }
                ]
            },
            {
                "imo": 8269772,
                "owner_id": 10,
                "signals": [
                    {
                        "signalname": "signaldate",
                        "source": "signals"
                    }
                ]
            }
        ]
    }
    return payload;
}
exports.signalMetadata = () => {
    let payload = [
        {
            owner_id: 10,
            imo: 8999748,
            signalName: 'TE3701A',
            datapoints: [
                [
                    1627166736000,
                    317.5
                ],
                [
                    1627166746000,
                    317.5
                ]
            ],
            source: 'ems_1_signals',
            message: undefined,
            csv_signal_name: '8999748.ems_1_signals.TE3701A'
        },
        {
            owner_id: 10,
            imo: 8999749,
            signalName: 'TE3701B',
            datapoints: [
                [
                    1627166736000,
                    317.5
                ],
                [
                    1627166746000,
                    317.5
                ]
            ],
            source: 'ems_2_signals',
            message: undefined,
            csv_signal_name: '8999749.ems_2_signals.TE3701B'
        }
    ]
    return payload;
}

exports.alarmdata = () => {
    let payload = {
        "imo": 1819839,
        "starttime": 1663925227702,
        "endtime": 1663925228046
    }
    return payload;
}

exports.datapointsReqData = () => {
    const payload = {
        "starttime": "2018-02-16T16:00:37.000Z",
        "endtime": "2018-02-16T16:05:18.000Z",
        "vessels": [
            {
                "imo": 8999748,
                "owner_id": 13,
                "signals": [
                    {
                        "description": ['Exhaust gas temp Cyl #01'],
                        "col_name": ['P1'],
                        "groupName": 'ems_1_signals',
                        "nameAtSource": ['TE3701A']
                    }
                ]
            },
            {
                "imo": 8999748,
                "owner_id": 13,
                "signals": [
                    {
                        "description": ['Exhaust gas temp Cyl #01'],
                        "col_name": ['P1'],
                        "groupName": 'ems_1_signals',
                        "nameAtSource": ['TE3701A']
                    }
                ]
            }
        ]
    }
    return payload;
}
exports.signalReqData = () => {
    let payload = [
        {
            "imo": 8269772
        },
        {
            "imo": 8999748,
            "signals": [
                {
                    "signalname": "TE3706C",
                    "source": "ems_1_failures"
                },
                {
                    "signalname": "EC_CylLubPressMeasFail1",
                    "source": "ems_1_failures"
                }
            ]
        }
    ]
    return payload;
}
exports.alarmReqData = () => {
    let payload = {
        "imo": 1819839,
        "starttime": 1663925227702,
        "endtime": 1663925228046
    }
    return payload;
}
exports.staticData = () => {
    const payload = {
        "imo": 8999748,
        "enginenumber": "99936",
        "dataset": "shoptest",
        "param": ["shaftP"]
    }
    return payload;
}
exports.vessels = () => {
    const payload = {
        "imo": [8999748]
    }
    return payload;
}