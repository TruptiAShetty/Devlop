/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const commonQuery = require('../database/queries/common.query');
const vessels = require('./unittest.controller.request.data')
jest.setTimeout(30000);
describe("common.query.js test", () => {
    let payload = vessels.downloadApiRequestBody();
    payload = payload.vessels;
    test("Get column data", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);
        const result = await commonQuery.getColumnName(payload, next);
    })
})
