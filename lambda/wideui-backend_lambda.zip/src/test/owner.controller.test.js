/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const ownerController = require("../controllers/owner.controller");

describe("owner.controller test", () => {

    let next = {};
    next = jest.fn().mockReturnValue(next);

    let res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.send = jest.fn().mockReturnValue(res);

    test("owner API", async () => {
        let payload = {
            "owner_id": [13]
        }

        const req = {body:payload}

        const result = await ownerController.postOwners(req, res, next);
    })
    test.only("negative scenario - without ownerId", async () => {
        let payload = {}

        const req = {body:payload}

        const result = await ownerController.postOwners(req, res, next);
    })
    test.only("negative scenario:empty list", async () => {
        let payload = {"owner_id": []}

        const req = {body:payload}

        const result = await ownerController.postOwners(req, res, next);
    })
})
