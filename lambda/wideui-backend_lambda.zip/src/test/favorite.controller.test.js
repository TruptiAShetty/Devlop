/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

const favorites = require("../controllers/favourite.controller");
// const commonQuery = require("../database/queries/common.query");
jest.setTimeout(30000);

describe("favourite.controller.js test", () => {
    let next = {};
    next = jest.fn().mockReturnValue(next);

    test("Get favorite", async () => {
        let req = { params: { id: 'Fav_C' }, headers: { "user_id": "123" } }

        let res = {
            status: (code) => {
                expect(code).toEqual(200)

            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }
        //  const result = await favorites.getFavourites(req, res, next);
    })

    test("Get favorite", async () => {
        let req = { params: { id: 'Fav_C' }, headers: { "user_id": null } }

        let res = {
            status: (code) => {
                expect(code).toEqual(200)

            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }
        //   const result = await favorites.getFavourites(req, res, next);
    })

    test("Get all favorites", async () => {
        let req = { params: { id: null }, headers: { user_id: 123 } }

        let res = {
            status: (code) => {
                expect(code).toEqual(200)

            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }

        //   const result = await favorites.getFavourites(req, res, next);
    })
    test.only("Get all favorites negative case", async () => {
        let req = { params: { id: null }, headers: {} }

        let res = {
            status: (code) => {
                expect(code).toEqual(200)

            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }

        // const result = await favorites.getFavourites(req, res, next);
    })
})

describe("favourite.controller.js DELETE test", () => {
    test("DELETE favorite", async () => {
        let req = { body: { user_id: '123', favorite_name: 'Fav_C' } }
        let next = {};
        next = jest.fn().mockReturnValue(next);
        let res = {
            status: (code) => {
                expect(code).toEqual(200)
            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }

        //   const result = await favorites.deleteFavourite(req, res, next);
    })
    test.only("DELETE favorite negative scenario", async () => {
        let req = { body: { favorite_name: '' } }
        let next = {};
        next = jest.fn().mockReturnValue(next);
        let res = {
            status: (code) => {
                expect(code).toEqual(200)
            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }

        // const result = await favorites.deleteFavourite(req, res, next);
    })
})

const reqData = require('./unittest.controller.request.data');
const payload = reqData.favoriteApiReqData();
describe("favourite.controller.js ADD test", () => {
    test("ADD favorite", async () => {
        let req = {
            body: payload
        }
        let next = {};
        next = jest.fn().mockReturnValue(next);
        let res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);

        //    const result = await favorites.addFavourite(req, res, next);
    })
    test.only("ADD favorite invalid request data", async () => {
        payload.starttime = "";
        payload.endtime = null;
        let req = {
            body: {}
        }
        let next = {};
        next = jest.fn().mockReturnValue(next);
        let res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);

        // const result = await favorites.addFavourite(req, res, next);
    })
})
