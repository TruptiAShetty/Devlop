/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const alarmevent = require('../database/queries/alarmevent.query')
const requestData = require('./unittest.controller.request.data');
describe("alarmevent.query.js test", () => {
    let payload = requestData.alarmdata();
    test("Get Alarm data", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);
        // const result = await alarmevent.getAlarmevents(payload, next);
    })
})