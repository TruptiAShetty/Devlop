/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const utils = require("../core/utility/common.utils")
const requestBody = require("./unittest.controller.request.data")
const os = require("os")
const fs = require("fs")
const path = require("path");

describe("common.utils test", () => {

    test("deleteTempDir API", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);

        let jsonContent = {"imo":1234};
        jsonContent = JSON.stringify(jsonContent);

        let outputDir = "tempDir";
        let tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), outputDir));
        fs.writeFileSync(tmpDir + "/signalData.json", jsonContent, { flag: "a+" });

        const result = await utils.deleteTempDir(tmpDir);
    })
})

describe("common.utils test", () => {

    test("get datetime", async () => {
        const result = await utils.getDateTime();
    })
})
describe("common.utils test", () => {
    const reqData = requestBody.signalMetadata();
    test("Grop signal meta data", async () => {
        const result = await utils.groupJsonData(reqData);
    })
})
describe("common.utils test", () => {
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.send = jest.fn().mockReturnValue(res);
    
    let jsonContent = {"imo":1234};
    jsonContent = JSON.stringify(jsonContent);
    let outputDir = "tempDir";
    let tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), outputDir));
    fs.writeFileSync(tmpDir + "/signalData.json", jsonContent, { flag: "a+" });
    let fileNames = ["signalData.json","invalid.json"];
    test("Download the zip file: negative scenario", async () => {
        const result = await utils.downloadFileBlob(tmpDir,fileNames);
    })
})
describe("common.utils test", () => {
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.send = jest.fn().mockReturnValue(res);
    res.set = jest.fn().mockReturnValue(res);
    res.download = jest.fn().mockReturnValue(res);

    let jsonContent = {"imo":1234};
    jsonContent = JSON.stringify(jsonContent);
    let outputDir = "tempDir";
    let tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), outputDir));
    fs.writeFileSync(tmpDir + "/signalData.json", jsonContent, { flag: "a+" });
    let fileNames = ["signalData.json"];
    test("Download the zip file", async () => {
        const result = await utils.downloadFileBlob(tmpDir,fileNames);
    })
})