/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

const renameAPI = require('../controllers/rename.controller');
const reqData = require('./unittest.controller.request.data');
const payload = reqData.renameApiReqData();
describe("rename.controller.js ADD test", () => {
    test.only("rename favorite", async () => {
        let req = {
            body: payload
        }
        let next = {};
        next = jest.fn().mockReturnValue(next);
        let res = {
            status: (code) => {
                expect(code).toEqual(200)
            },
            send: (val) => {
                expect(val).toEqual(200)
            }
        }

        // const result = await renameAPI.renameFavorite(req, res, next);
    })
})