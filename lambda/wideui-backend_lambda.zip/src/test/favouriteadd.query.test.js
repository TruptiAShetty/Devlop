/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

const favAddQuery = require("../database/queries/favouriteadd.query");
const mysql = require("../database/db");
jest.setTimeout(30000);

describe("favouriteadd.query.js test", () => {
    const payload = {
        "starttime": 1518796837000,
        "endtime": 1518797118000,
        "favorite_name": "Fav_test",
        "user_id": 123,
        "vessels": [
            {
                "imo": 8999748,
                "signals": [
                    {
                        "signalname": "TE3706C",
                        "source": "ems_1_failures",
                        "color": "#5505d3",
                        "display_rangemax": 1,
                        "display_rangemin": -1
                    },
                    {
                        "signalname": "EC_CylLubPressMeasFail1",
                        "source": "ems_1_failures",
                        "color": "#5505d3",
                        "display_rangemax": 1,
                        "display_rangemin": -1
                    }

                ]
            }
        ]
    }
    test("Add favorite", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);
        // const result = await favAddQuery.favadd(payload, next);
    })
})
