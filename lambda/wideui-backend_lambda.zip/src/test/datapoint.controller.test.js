/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const datapointController = require("../controllers/datapoint.controller");
const requestBody = require("./unittest.controller.request.data");
jest.setTimeout(30000);
const payload = requestBody.downloadApiRequestBody();
describe("datapoint.controller test", () => {

    test("datapoint API", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);

        const res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);

        const req = { body: payload }

        const result = await datapointController.postDatapoints(req, res, next);
    })
    test.only("datapoint API invalid requestdata", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);

        let res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);
        payload.starttime = null;
        const req = { body: payload }

        // const result = await datapointController.postDatapoints(req, res, next);
    })
})
