/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const alarmController = require("../controllers/alarmevent.controller");
let reqData = require("./unittest.controller.request.data")
describe("alarmevent.controller test", () => {

    test.only("alarmevent API", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);

        const res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);

        const req = {body:reqData};

        const result = await alarmController.postAlarmevent(req, res, next);
    })
})