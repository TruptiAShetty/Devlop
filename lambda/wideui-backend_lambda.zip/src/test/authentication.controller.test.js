/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const authController = require("../controllers/authentication.controller");
describe("authentication.controller test", () => {

    test.only("Invalid Auth Token", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);

        let res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);

        const req = {headers:{authorization:'YWRtaW46QWR'}}

        const result = await authController.postLogin(req, res, next);
    })

    test("Auth API", async () => {
        let next = {};
        next = jest.fn().mockReturnValue(next);

        let res = {};
        res.status = jest.fn().mockReturnValue(res);
        res.send = jest.fn().mockReturnValue(res);

        const req = {headers:{authorization:'Basic YWRtaW46QWRtaW5AMTIz'}}

        const result = await authController.postLogin(req, res, next);
    })
})