/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const ErrorResponse = require("../core/utility/error-response");

const requestDataValidator = (req) => {
	let { starttime, endtime, vessels, resolution } = req.body;

	if (!starttime) {
		return new ErrorResponse("starttime field is required", 400);
	}

	if (isNaN(starttime)) {
		return new ErrorResponse("starttime must be an EPOC timestamp", 400);
	}

	if (!endtime) {
		return new ErrorResponse("endtime field is required", 400);
	}

	if (isNaN(endtime)) {
		return new ErrorResponse("endtime must be an EPOC timestamp", 400);
	}

	if (!endtime) {
		return new ErrorResponse("endtime field is required", 400);
	}

	if (!resolution) {
		return new ErrorResponse("resolution field is required", 400);
	}

	if (!req.body.hasOwnProperty("resolution")) {
		return new ErrorResponse("Object must have 'resolution' property specified !", 400);
	}

	if (!vessels?.length) {
		return new ErrorResponse("Request payload must have vessels field specified", 400);
	}

	for (const row of vessels) {
		if (!row.hasOwnProperty("imo")) {
			return new ErrorResponse("Each vessel object must have 'imo' property specified !", 400);
		} else {
			if (!row.hasOwnProperty("signals")) {
				return new ErrorResponse(
					"Each vessel object must have 'signals' property specified !",
					400
				);
			} else {
				for (const signal of row.signals) {
					if (!signal.hasOwnProperty("signalname")) {
						return new ErrorResponse(
							"Each signal object must have 'signalname' property specified !",
							400
						);
					}
					if (!signal.hasOwnProperty("source")) {
						return new ErrorResponse(
							"Each signal object must have 'source' property specified !",
							400
						);
					}
				}
			}
		}
	}

	return new ErrorResponse("Success", 200);
};

module.exports = requestDataValidator;
