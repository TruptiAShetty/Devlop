/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const ErrorResponse = require("../core/utility/error-response");

const signalRequestValidator = (req) => {
	const signalsPayload = req.body;
	if (!signalsPayload) {
		return new ErrorResponse("Request can not be empty !", 400);
	}

	if (!signalsPayload.length) {
		return new ErrorResponse(
			"Request can not be empty, please provide at least one object with imo specified",
			400
		);
	}

	for (const row of signalsPayload) {
		if (!row.hasOwnProperty("imo")) {
			return new ErrorResponse("Each object must have imo property specified !", 400);
		}
		if (row?.signals) {
			for (const r of row.signals) {
				if (!r.hasOwnProperty("signalname")) {
					return new ErrorResponse(
						"Each signal object must have 'signalname' property specified !",
						400
					);
				}
				if (!r.hasOwnProperty("source")) {
					return new ErrorResponse(
						"Each signal object must have 'source' property specified !",
						400
					);
				}
			}
		}
	}

	return new ErrorResponse("Success", 200);
};

module.exports = signalRequestValidator;
