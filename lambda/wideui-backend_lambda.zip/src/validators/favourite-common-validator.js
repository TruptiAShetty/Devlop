/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const ErrorResponse = require("../core/utility/error-response");
exports.favouriteDataValidator = (req, res, next) => {
	let { starttime, endtime, user_id, favorite_name, vessels } = req.body;

	if (!starttime) {
		return next(new ErrorResponse("starttime field is required", 400));
	}

	if (isNaN(starttime)) {
		return next(new ErrorResponse("starttime must be an EPOC timestamp", 400));
	}

	if (!endtime) {
		return next(new ErrorResponse("endtime field is required", 400));
	}

	if (isNaN(endtime)) {
		return next(new ErrorResponse("endtime must be an EPOC timestamp", 400));
	}

	if (!endtime) {
		return next(new ErrorResponse("endtime field is required", 400));
	}

	if (!req.body.hasOwnProperty("endtime")) {
		return next(new ErrorResponse("Object must have 'endtime' property specified !", 400));
	}

	if (!favorite_name) {
		return next(new ErrorResponse("favorite_name field is required", 400));
	}

	if (!req.body.hasOwnProperty("favorite_name")) {
		return next(new ErrorResponse("Object must have 'favorite_name' property specified !", 400));
	}

	if (!user_id) {
		return next(new ErrorResponse("user_id field is required", 400));
	}

	if (!req.body.hasOwnProperty("user_id")) {
		return next(new ErrorResponse("Object must have 'user_id' property specified !", 400));
	}

	if (!vessels?.length) {
		return next(new ErrorResponse("Request payload must have vessels field specified", 400));
	}

	for (const row of vessels) {
		if (!row.hasOwnProperty("imo")) {
			return next(
				new ErrorResponse("Each vessel object must have 'imo' property specified !", 400)
			);
		} else {
			if (!row.hasOwnProperty("signals")) {
				return next(
					new ErrorResponse("Each vessel object must have 'signals' property specified !", 400)
				);
			} else {
				for (const signal of row.signals) {
					if (!signal.hasOwnProperty("signalname")) {
						return next(
							new ErrorResponse(
								"Each signal object must have 'signalname' property specified !",
								400
							)
						);
					}
					if (!signal.hasOwnProperty("source")) {
						return next(
							new ErrorResponse("Each signal object must have 'source' property specified !", 400)
						);
					}
					if (!signal.hasOwnProperty("color")) {
						return next(
							new ErrorResponse("Each signal object must have 'color' property specified !", 400)
						);
					}
					if (!signal.hasOwnProperty("display_rangemax")) {
						return next(
							new ErrorResponse("Each signal object must have 'display_rangemax' property specified !", 400)
						);
					}
					if (!signal.hasOwnProperty("display_rangemin")) {
						return next(
							new ErrorResponse("Each signal object must have 'display_rangemin' property specified !", 400)
						);
					}
				}
			}
		}
	}
	return new ErrorResponse("Success", 200);
};

exports.getRequestDataValidator = (req) => {
  if (!req.headers.hasOwnProperty("user_id")) {
      return new ErrorResponse(
          "Request header must have 'user_id' property specified !",
          400
      );
  }
  return new ErrorResponse("Success", 200);
};

exports.deleteRequestDataValidator = (req) => {
	if (!req.body.hasOwnProperty("favorite_name")) {
		return new ErrorResponse(
			"Object must have 'favorite_name' property specified !",
			400
		);
	}
	if (!req.body.hasOwnProperty("user_id")) {
		return new ErrorResponse(
			"Object must have 'user_id' property specified !",
			400
		);
	}
	return new ErrorResponse("Success", 200);
};