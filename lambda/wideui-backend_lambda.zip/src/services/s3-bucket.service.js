/*
 *   Copyright (c) 2023 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */

const AWS = require("aws-sdk");
const config = require("../core/config/config.json");

AWS.config.update({
    accessKeyId: config.aws.accessKeyId,
    secretAccessKey: config.aws.secretAccessKey,
    region: config.aws.region
});

const S3 = new AWS.S3();

// Get buffered file from s3
const getBufferFromS3 = (file, callback) => {
    const bucketName = config.S3.bucketName;
    const objectKey = file;
    const buffers = [];
    const s3 = new AWS.S3();
    const stream = s3
        .getObject({
            Bucket: bucketName,
            Key: objectKey
        })
        .createReadStream();
    stream.on("data", (data) => buffers.push(data));
    stream.on("end", () => callback(null, Buffer.concat(buffers)));
    stream.on("error", (error) => callback(error));
};

const bucketName = config.S3.bucketName;

module.exports = {
    listBucketContent: (filePath) =>
        new Promise((resolve, reject) => {
            const params = { Bucket: bucketName, Prefix: filePath };
            S3.listObjects(params, (err, objects) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(objects);
                }
            });
        }),

    // promisify read stream from s3
    getBufferFromS3Promise: (file) => {
        return new Promise((resolve, reject) => {
            getBufferFromS3(file, (error, s3buffer) => {
                if (error) return reject(error);
                return resolve(s3buffer);
            });
        });
    },

    getFileFromS3: (filePath) => {
        return new Promise((resolve, reject) => {
            try {
                S3.getObject(
                    {
                        Bucket: bucketName,
                        Key: filePath
                    },
                    (err, data) => {
                        if (err) {
                            reject(err);
                        } else {
                            //  console.log('Unparsed fetched object data', JSON.parse(data.Body.toString('utf-8')));
                            // resolve(data.Body.toString('utf-8'));

                            resolve(data);
                        }
                    }
                );
            } catch (e) {
                reject(e);
            }
        });
    }
};
