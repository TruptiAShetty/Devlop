/*
 *   Copyright (c) 2022 Winterthur Gas & Diesel Ltd. (https://wingd.com)
 *   All rights reserved.
 *   All files in this SharePoint shall not be copied and/or distributed and/or used for other purposes than agreed without the prior written permission of Winterthur Gas & Diesel Ltd.
 */
const AWS = require("aws-sdk");
const CryptoJS = require("crypto-js");
const Base64 = require("crypto-js/enc-base64");
const config = require("../core/config/config.json");

class CongnitoService {
	cognitoIdentity;
	config = {
		region: config.aws.region
	};
	secretHash = config.cognito.secretHash;
	clientId = config.cognito.appClientId;

	constructor() {
		this.cognitoIdentity = new AWS.CognitoIdentityServiceProvider(this.config);
	}

	async signUp(username, password, cb) {
		const params = {
			ClientId: this.clientId,
			Password: password,
			Username: username,
			SecretHash: this.generateHash(username),
			UserAttributes: []
		};

		console.log("params", params);

		try {
			this.cognitoIdentity.signUp(params, (err, data) => {
				if (err) cb(err); // an error occurred
				else cb(null, data); // successful response
			});
		} catch (error) {
			console.log(error);
		}
	}

	async signInUser(username, password, cb) {
		const params = {
			AuthFlow: "USER_PASSWORD_AUTH",
			ClientId: this.clientId,
			AuthParameters: {
				USERNAME: username,
				PASSWORD: password,
				SECRET_HASH: this.generateHash(username)
			}
		};

		try {
			this.cognitoIdentity.initiateAuth(params, (err, data) => {
				if (err) cb(err); // an error occurred
				else cb(null, data); // successful response
			});
		} catch (error) {
			console.log(error);
			return false;
		}
	}

	async getUser(token, cb) {
		var params = {
			AccessToken: token /* required */
		};

		try {
			this.cognitoIdentity.getUser(params, (err, data) => {
				if (err) cb(err); // an error occurred
				else cb(null, data); // successful response
			});
		} catch (e) {
			console.log(error);
			return false;
		}
	}

	generateHash(username) {
		return Base64.stringify(CryptoJS.HmacSHA256(username + this.clientId, this.secretHash));
	}
}

module.exports = CongnitoService;
